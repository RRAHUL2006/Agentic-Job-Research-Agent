# The LangChain Guide

LangChain provides the individual building blocks this project's
LangGraph assembles into a workflow.

## Chat models

A unified interface over different LLM providers: `.invoke(messages)`
returns a response, regardless of whether the underlying model is Ollama,
OpenAI, Anthropic, etc. `app/agent/llm.py::get_llm()` returns a
`ChatOllama` instance — this project's only chat model — configured once
from `app/config.py`.

## Tools

A `@tool`-decorated Python function becomes something an LLM can be told
about and asked to call. LangChain turns the function's signature and
docstring into a JSON schema the model receives in its prompt context.
Every tool in `app/tools/*.py` follows this pattern:

```python
@tool
def calculate_match_score(job_skills_json: str, user_skills_json: str) -> dict:
    """<docstring becomes the tool description the LLM sees>"""
    return safe_tool_call(_calculate_match_score, ...)
```

The docstring matters a lot — it's the only information the model has
about when and how to use the tool.

## Tool calling

`llm.bind_tools([...])` (see `app/agent/llm.py::get_llm`) tells the model
which tools are available. When invoked, the model's response
(`AIMessage`) may include a `tool_calls` list instead of (or alongside)
plain text. Your code — not LangChain — is responsible for actually
executing those calls; see `app/graph/nodes.py::tool_node`.

## Prompt templates

This project uses plain `SystemMessage`/`HumanMessage` objects built with
f-strings (see `SYSTEM_PROMPT` and `_format_evidence`/`_format_plan` in
`app/graph/nodes.py`) rather than LangChain's `PromptTemplate` classes —
simpler to read for a learning project, and there's no templating need
beyond string interpolation here. `PromptTemplate` is worth learning once
you need reusable prompts with formal input-variable validation.

## Retrievers

LangChain has a `BaseRetriever` interface for "text in, relevant
documents out." This project implements the same *idea* directly against
pgvector (`app/retrieval/retriever.py`) rather than through LangChain's
retriever class, so the exact SQL/pgvector operators are visible and
teachable instead of hidden behind an abstraction.

## Embeddings

`OllamaEmbeddings` (see `app/retrieval/embeddings.py`) turns text into a
vector. LangChain gives every embedding provider the same
`.embed_query(text)` / `.embed_documents(texts)` interface, which is why
swapping to a different embedding model later is a one-line change.

## Output parsers

Not used directly in this project — tool calling already gives us
structured (JSON-shaped) output from the model for anything that needs
it. Output parsers become relevant when you want structured output
*without* a tool-calling round-trip (e.g. forcing a plain-text response
into a Pydantic model). Worth exploring once you're comfortable with
tool calling.
