# Architecture

## One-paragraph summary

A user sends a natural-language request. A LangGraph `StateGraph` routes it
through a **planner** (breaks the request into steps), a **retriever**
(pulls relevant evidence from pgvector before reasoning starts), an
**agent** (an LLM bound to tools that decides what to do next), a
**tools** node (executes whatever the agent asked for), a **reflection**
node (checks the draft answer against the request and evidence, and can
send the agent back for another pass), and a **finalizer** (guarantees a
response is always returned). Every node writes concise trace events to
PostgreSQL so the whole execution is inspectable afterward.

## Diagram

```
START
  |
planner            <- LLM call (no tools): breaks request into a task list
  |
retriever          <- pgvector similarity search over ingested documents
  |
agent <----------------------------+
 |  \                              |
 |   \ (no tool call)              |
 |    v                            |
 | reflection --FAIL,retries left--+   (loops back to agent with feedback)
 |    |
 |   PASS or retries exhausted
 |    v
 | finalizer
 |    |
 |   END
 |
 v (tool call requested)
tools --------------------------> (back to agent)
```

## Why each technology

- **LangChain**: gives us a uniform `ChatModel` + `@tool` abstraction so
  swapping Ollama for another provider later touches one file
  (`app/agent/llm.py`), not the whole codebase.
- **LangGraph**: the request needs *branches* (tool call or not?) and
  *loops* (keep calling tools until done; retry on failed reflection).
  A plain LangChain chain is a straight line; LangGraph is a graph.
- **PostgreSQL**: every table in this system (sessions, memories, traces,
  evaluations, plans) is relational, normalized data that benefits from
  real transactions and foreign keys — not a fit for a key-value store or
  local file, and it needs to survive restarts (unlike LangGraph's
  in-memory state).
- **pgvector**: adds vector similarity search *inside* the same database
  as the rest of the app's data. No separate vector DB to run, back up,
  or keep in sync.
- **Ollama**: local inference. No API keys required to run the whole
  project, and it's a realistic stand-in for how production agents call
  any chat-completions-shaped model.

## Data flow: one request, end to end

1. `app/api/main.py` (`POST /agent`) or `app/ui/streamlit_app.py` calls
   `app/agent/runtime.run_agent()`.
2. `run_agent()` ensures a `User`/`ChatSession` row exists, builds the
   initial `AgentState` (`app/graph/state.py`), and calls the compiled
   graph (`app/graph/graph.py`).
3. Each node in `app/graph/nodes.py` reads/writes `AgentState` and (for
   tool calls, traces, plans) persists rows to Postgres as it goes.
4. `run_agent()` persists the final assistant message and returns a plain
   dict — the API and UI layers never touch LangGraph objects directly.

## Where to look for each concept

| Concept | File |
|---|---|
| Agent state | `app/graph/state.py` |
| Planning | `app/graph/nodes.py::planner_node` |
| Tool calling | `app/graph/nodes.py::agent_node`, `app/tools/registry.py` |
| Conditional routing / loops | `app/graph/edges.py` |
| Long-term memory | `app/tools/memory_tools.py` |
| RAG | `app/retrieval/` |
| Reflection | `app/graph/nodes.py::reflection_node` |
| Evaluation | `app/evaluation/` |
| Observability | `app/db/models.py::AgentTrace`, Streamlit "Agent Graph" tab |
