# The Agentic AI Guide

A plain-English walk through every concept this project demonstrates, in
the order you'd learn them.

## What is an LLM?

A large language model is a function: give it text (a "prompt"), it
predicts the most likely continuation, token by token. `app/agent/llm.py`
wraps this as `ChatOllama` — you hand it a list of messages, it hands
back a message.

## What is a prompt?

The text you send the model, including any instructions ("You are a job
research agent...", see `SYSTEM_PROMPT` in `app/graph/nodes.py`). Prompt
engineering is the practice of writing that instruction text so the
model's behavior is predictable.

## What is tool calling?

Modern chat models can be given a list of function *signatures* (name,
description, parameters) and asked to either answer in plain text OR
emit a structured request to call one of those functions. The model
never actually runs code — it just says "call `search_jobs` with
`{keyword: 'data engineer'}`" — your application (here, `tool_node` in
`app/graph/nodes.py`) is what actually executes it and feeds the result
back.

## What is an agent?

A program that loops: ask the model what to do → do it (call a tool) →
show the model the result → ask again → ... → until the model decides
it's done. `app/graph/nodes.py::agent_node` plus `tool_node` plus the
`agent ⇄ tools` edge in `app/graph/graph.py` together implement exactly
this loop.

## What is state?

Everything the agent needs to remember *during* one request: the
conversation so far, the plan, retrieved evidence, tool results, error
count. See `app/graph/state.py::AgentState`. This is different from
long-term memory (below) — state lives for one request; memory survives
across requests.

## What is LangChain?

A library of building blocks: a common interface for chat models
(`ChatOllama`, but swappable), a common `@tool` decorator for turning
Python functions into things an LLM can call, and helpers for prompts,
retrievers, and output parsing. This project uses LangChain for the
model interface and the tool abstraction; see `LANGCHAIN_GUIDE.md`.

## What is LangGraph?

A library built on top of LangChain for structuring an agent as an
explicit graph of nodes and edges (rather than one big function with
lots of `if` statements). See `LANGGRAPH_GUIDE.md` for the full
breakdown.

## What is a graph node?

One step in the workflow — a Python function that takes the current
state and returns updates to it. `planner_node`, `agent_node`,
`tool_node`, `reflection_node`, and `finalizer_node` in
`app/graph/nodes.py` are all graph nodes.

## What is conditional routing?

Instead of always going `A → B`, a routing function looks at the current
state and decides `A → B` or `A → C`. `app/graph/edges.py::route_after_agent`
is the clearest example: "did the model ask for a tool? go to `tools`.
Otherwise go to `reflection`."

## What is memory?

Anything that survives past the current request. This project has three
kinds:
1. **Conversation history** — stored as `Message` rows (short-term, but persisted).
2. **Key/value memory** — `remember`/`recall` tools, `Memory` table: "target_role = Data Engineering".
3. **Semantic memory** — `SemanticMemory` table: free-text memories found by *meaning*, not exact key match.

## What is RAG?

Retrieval-Augmented Generation: before (or during) generating an answer,
search a knowledge base for relevant text and include it in the prompt,
so the model can ground its answer in real documents instead of
recalling (and potentially misremembering) facts from training. See
`RAG_GUIDE.md`.

## What is reflection?

A second LLM pass that checks the *first* pass's draft answer against
the original request and the evidence gathered, and can send it back for
revision. It's the difference between "the model produced an answer" and
"the model's answer was checked before being shown to the user."

## What is evaluation?

Running the whole system against a fixed set of test cases and measuring
concrete numbers (success rate, latency, tool-selection accuracy) instead
of eyeballing a few chat transcripts. See `EVALUATION.md`.

## What are multi-agent systems?

Instead of one agent with access to every tool, split responsibilities
across several narrower agents (a research specialist, a job specialist,
a skill specialist...) coordinated by a supervisor. See
`app/graph/supervisor.py` for an optional, fully-documented extension —
read it only after the single-agent graph makes sense to you.
