# The PostgreSQL Guide

## Why PostgreSQL instead of SQLite?

SQLite is a single file with no server — great for a quick script, but:

- **Concurrency**: SQLite locks the whole database file for writes. This
  project's API server, Streamlit UI, and background evaluation runs
  could all be writing at once (new messages, tool_call rows, traces) —
  Postgres handles concurrent writers correctly; SQLite would serialize
  or error under the same load.
- **pgvector**: the vector similarity search this project depends on for
  RAG and semantic memory is a PostgreSQL extension. There's no SQLite
  equivalent with the same maturity.
- **Production realism**: almost every real deployment of a system like
  this runs against a managed Postgres instance. Learning Postgres here
  transfers directly; learning SQLite's quirks mostly doesn't.

## Tables

See `app/db/models.py` for the full schema (13 tables). A few worth
understanding by role rather than name:

- **Identity/conversation**: `users`, `sessions`, `messages` — a fairly
  standard chat-app schema.
- **Memory**: `memories` (exact key/value) and `semantic_memories`
  (vector-searchable free text) — two different memory strategies, see
  `AGENTIC_AI_GUIDE.md`.
- **RAG**: `documents` (one row per ingested source) and
  `document_chunks` (one row per chunk, each with its own embedding —
  see `PGVECTOR_GUIDE.md` for why chunking matters).
- **Domain data**: `jobs`, `companies` — the actual subject matter the
  agent researches.
- **Observability**: `tool_calls` (one row per tool invocation) and
  `agent_traces` (one row per graph-node transition) — this is what
  powers the Streamlit "Agent Graph" and "Tools" tabs.
- **Planning/evaluation**: `plans`/`tasks` (the planner node's output,
  persisted) and `evaluations` (results from the evaluation suite).

## Indexes

Every foreign key column used in a lookup (`session_id` on `messages`,
`user_id` on `memories`, etc.) has `index=True` in the model definition.
Rule of thumb: if a column appears in a `WHERE` or `JOIN` clause
frequently, it should be indexed. Un-indexed foreign keys are one of the
most common real-world Postgres performance bugs.

## Transactions

`app/db/session.py::session_scope()` wraps every unit of work in a
transaction: commits on success, rolls back on any exception, always
closes the session. This means a node that fails halfway through writing
several rows (e.g. a plan's tasks) won't leave the database in a
half-written state.

```python
with session_scope() as db:
    db.add(row_a)
    db.add(row_b)
    # both committed together, or neither is, if an exception is raised
```

## SQLAlchemy

The ORM layer (`app/db/models.py`) lets us write Python classes instead
of raw SQL for everyday CRUD, while still dropping to raw SQL
(`sqlalchemy.text(...)`) where it's clearer — see the `pgvector` health
check in `app/api/main.py`. `Mapped[...]` type annotations (SQLAlchemy
2.0 style) give you IDE autocomplete and type checking on every column.

## Persistence

Because everything lives in Postgres rather than in-process memory, you
can kill and restart the API server, the Streamlit app, or a background
evaluation run, and all conversation history, memories, and traces are
still there. This is what makes `app/agent/runtime.py::run_agent()`
stateless from the caller's perspective — hand it a `session_id`, it
reconstructs whatever context it needs from the database.
