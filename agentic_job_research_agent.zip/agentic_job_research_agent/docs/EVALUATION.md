# Evaluation

## Why evaluate an agent at all?

A chatbot demo can look great in a five-message conversation and still
fail regularly in practice. Evaluation replaces "it seemed to work when I
tried it" with numbers you can compare across changes: did a prompt
tweak actually improve tool selection, or just make the model chattier?

## What's measured, and how

| Dimension | How it's measured here | Where |
|---|---|---|
| Task success rate | Does the final answer contain the expected keywords (or, for the simulated-failure task, did the system degrade gracefully)? | `app/evaluation/metrics.py::keyword_success` / `recovered_gracefully` |
| Tool selection accuracy | Was the *expected* tool actually called for this task? | `metrics.py::tool_selection_correct` |
| Groundedness | Does the final answer reference the retrieved evidence, rather than ignoring it? (naive substring-overlap proxy) | `metrics.py::groundedness_score` |
| Latency | Wall-clock time for the full graph run | `evaluator.py::_run_single_task` |
| Number of steps | `AgentState.step_count` at the end of the run | same |
| Failure recovery | For the one task that deliberately triggers a tool error: did the system still return a usable answer instead of crashing? | `metrics.py::recovered_gracefully` |

Retrieval quality and memory accuracy aren't separate formulas — they're
measured the same way, via dedicated tasks (`retrieve_a_preference`,
etc.) in the dataset, scored with the same `keyword_success` /
`tool_selection_correct` functions.

Tool-call efficiency and reflection effectiveness are visible in the
per-task `step_count` and in the `reflection_retries` field of
`AgentState` (surfaced via `agent_traces`) — worth graphing over time as
you tune prompts, though this project doesn't compute a single scalar
for either; that's a natural extension once you have a few evaluation
runs to compare.

## The dataset

`app/evaluation/datasets.py::EVAL_TASKS` — 11 tasks (the spec asked for
at least 10), covering: job search, company research, profile
comparison, saving/retrieving a preference, skill-gap identification,
learning-plan creation, multi-job comparison, an unknown company (tests
graceful "no data found" handling), and one deliberately-malformed input
(tests error recovery).

## Running it

- **API**: `POST /evaluate` (optionally `{"task_name": "research_bp"}`
  to run just one task).
- **UI**: Streamlit → Evaluation tab → "Run full evaluation suite" button.
- **Script**: `python -c "from app.evaluation.evaluator import run_evaluation_suite; print(run_evaluation_suite())"`

Every run calls the **real** agent (`run_agent()`), so it needs Postgres
and Ollama running — this is intentionally not mocked, since the whole
point is catching regressions in the actual graph, not a simulation of
it.

## Where results go

Every task result is written to the `evaluations` table
(`app/db/models.py::Evaluation`), so `run_evaluation_suite()` output is
also queryable historically — the Streamlit Evaluation tab's "Historical
evaluation runs" table reads straight from it.

## Extending this

- Swap the naive `groundedness_score` substring check for an LLM-as-judge
  call (ask a second model: "does this answer use the provided
  evidence? yes/no") for a much stronger signal at the cost of an extra
  LLM call per evaluation.
- Add a `expected_min_score` field to `EvalTask` and assert on the actual
  numeric output of `calculate_match_score` for tasks that call it, for a
  stronger correctness check than keyword matching.
