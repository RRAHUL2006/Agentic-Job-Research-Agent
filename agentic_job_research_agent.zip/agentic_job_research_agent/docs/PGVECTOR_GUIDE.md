# The pgvector Guide

## Embeddings

An embedding is a list of floating-point numbers (a vector) that
represents the *meaning* of a piece of text, produced by an embedding
model (`nomic-embed-text` via Ollama in this project — see
`app/retrieval/embeddings.py`). Texts with similar meaning end up with
vectors that point in similar directions in that high-dimensional space,
even if they don't share any exact words. `settings.embedding_dim = 768`
is the length of every vector `nomic-embed-text` produces.

## Vectors

Just an ordered list of numbers, `[0.0123, -0.441, ..., 0.087]` — but
because embedding models are trained so that geometric closeness tracks
semantic closeness, we can use plain vector math to find "similar"
pieces of text.

## Cosine similarity

Given two vectors, cosine similarity measures the angle between them
(ignoring their length): `1.0` means pointing in exactly the same
direction (near-identical meaning), `0.0` means unrelated, `-1.0` means
opposite. pgvector's `<=>` operator computes **cosine distance**
(`1 - cosine_similarity`), which is why
`app/retrieval/retriever.py` converts it back:
`similarity = 1.0 - distance`.

## Nearest-neighbor search

"Find the K chunks whose embeddings are closest to my query's embedding"
is exactly what:

```sql
SELECT * FROM document_chunks
ORDER BY embedding <=> :query_embedding
LIMIT :top_k;
```

does. pgvector supports this as a native SQL operator — no separate
service, no manually looping through every row in Python computing
distances yourself. `app/retrieval/retriever.py::retrieve_documents`
builds exactly this query via SQLAlchemy's
`DocumentChunk.embedding.cosine_distance(query_embedding)`.

## Why pgvector is useful for RAG

Without it, "search my documents for relevant context" would mean either
(a) a separate vector database (Pinecone, Weaviate, Qdrant...) that you
now have to run, secure, and keep in sync with your relational data, or
(b) pulling every row into Python and computing distances by hand — fine
for a toy dataset, falls over fast at scale. pgvector gives you real
vector search *inside* the same database as your relational data, so a
single query can even combine a `WHERE doc_type = 'resume'` relational
filter with a vector similarity `ORDER BY` — which is exactly what
`retrieve_documents(..., doc_type=...)` does.

## A worked example

1. User asks: *"What should I study for a BP Data Engineer interview?"*
2. `app/retrieval/embeddings.py::embed_text()` turns that question into a
   768-number vector using the same model that embedded every stored
   chunk.
3. `retrieve_documents()` asks pgvector: "of all rows in
   `document_chunks`, which K have embeddings closest to this one?"
4. Postgres returns (for example) the chunk from
   `data/knowledge/sample_company_notes.md` about BP's data-engineering
   interview themes — found by *meaning*, even though the user's question
   didn't use the exact words "pipeline design trade-offs."
5. That chunk's text is handed to the LLM as evidence, with its source
   and similarity score attached for citation.
