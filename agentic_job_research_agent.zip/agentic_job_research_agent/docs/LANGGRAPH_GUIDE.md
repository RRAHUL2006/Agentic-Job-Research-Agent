# The LangGraph Guide

LangGraph models an agent as a **graph**: nodes that do work, edges that
decide what runs next. This project's graph lives in `app/graph/`.

## StateGraph

`StateGraph(AgentState)` (see `app/graph/graph.py`) is the graph builder.
You give it a schema (`AgentState`, a `TypedDict`) describing what data
flows through every node, then register nodes and edges on it, then
`.compile()` it into a runnable object.

## State

A single dict-like object passed to every node and returned (as a
partial update) from every node. LangGraph merges each node's return
value into the running state using per-field **reducers**. Most fields
in `AgentState` just get overwritten by the latest value; `messages` uses
a special reducer (see below).

## Nodes

A node is `def my_node(state: AgentState) -> dict`. It reads whatever
fields it needs from `state` and returns a dict of the fields it wants to
update. It does NOT mutate `state` in place — LangGraph owns merging.
Every node in this project follows this shape; see `app/graph/nodes.py`.

## Edges

A plain edge (`graph.add_edge("planner", "retriever")`) always goes from
one node straight to another — no decision involved.

## Conditional edges

`graph.add_conditional_edges("agent", route_after_agent, {"tools": "tools", "reflection": "reflection"})`

`route_after_agent` is a plain function `(state) -> str`; LangGraph calls
it after the `agent` node runs and sends execution to whichever node name
it returned. This is how the graph *branches*. See `app/graph/edges.py`.

## ToolNode / tool execution

LangGraph ships a generic `ToolNode`, but this project uses a **custom**
`tool_node` (`app/graph/nodes.py`) instead, because we need extra
behavior a generic node doesn't give us for free: writing every call to
the `tool_calls` table, refusing unregistered tool names, and containing
exceptions so one bad tool call can't crash the whole graph.

## Loops

A graph is allowed to have cycles. `graph.add_edge("tools", "agent")`
means: after tools run, go back to the agent. Combined with
`route_after_agent` sending tool-call requests to `tools`, this creates
the classic ReAct-style loop: *reason → act → observe → reason → ...*
until the agent stops requesting tools. `reflection → agent` is a second,
independent loop (bounded by `settings.max_reflection_retries`) for
answer quality instead of tool use.

**Why not loop forever?** Two guards: `route_after_agent` checks
`step_count >= settings.max_agent_steps` and forces a trip to
`reflection` regardless of pending tool calls; `route_after_reflection`
checks `reflection_retries` against `settings.max_reflection_retries`.
Always bound your loops.

## Checkpoints

LangGraph supports persisting state between `.invoke()` calls via a
*checkpointer* (e.g. `langgraph-checkpoint-postgres`, already in
`requirements.txt`), which enables pausing a graph mid-execution and
resuming it later — the mechanism human-in-the-loop approval (below)
would build on. This project keeps state in-memory for the duration of
one request (durable history instead lives in the `messages`/`sessions`
tables via `app/agent/runtime.py`), so no checkpointer is wired up by
default. Adding one is a natural next exercise: swap
`graph.compile()` for `graph.compile(checkpointer=...)`.

## Human-in-the-loop

The idea: some tool calls are too consequential to run automatically
(sending an email, submitting a job application). A node checks for
this and, instead of proceeding, sets `approval_required=True` and pauses
(via a checkpointer) until a human approves. `AgentState.approval_required`
and section 21 of the original spec describe this as a framework
extension — this read-only project doesn't have any tools that need it
yet, but the state field and the concept are here so you can add one.
