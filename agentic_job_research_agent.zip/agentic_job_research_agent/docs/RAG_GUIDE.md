# The RAG Guide

RAG = Retrieval-Augmented Generation. Instead of relying purely on what
an LLM memorized during training, you retrieve relevant text from your
own data at request time and include it in the prompt, so the model's
answer is *grounded* in real, checkable sources.

## The pipeline

```
text  ──chunk_text()──▶  chunks  ──embed_texts()──▶  vectors
  │                                                       │
  └──────────────────────── stored in Postgres ◀──────────┘
                        (documents + document_chunks)

query ──embed_text()──▶ query vector ──pgvector <=>──▶ top-K chunks
                                                             │
                                                             ▼
                                                    handed to the LLM
                                                     as evidence
```

Implemented across four files, each with one job:

| Step | File | What it does |
|---|---|---|
| 1. Chunk | `app/retrieval/chunker.py` | Splits long text into overlapping windows small enough to embed meaningfully. |
| 2. Embed | `app/retrieval/embeddings.py` | Text → vector, via Ollama. |
| 3. Store | `app/retrieval/documents.py`, `ingest.py` | Persist `Document` + `DocumentChunk` rows with their vectors. |
| 4. Retrieve | `app/retrieval/retriever.py` | Query → vector → pgvector `ORDER BY <=>` → top-K chunks. |

## Why chunk at all?

Embedding an entire resume as one vector averages together everything in
it — "5 years Python" and "hobbies: photography" end up blended into one
point in vector space. A query about Python experience competes against
the whole document instead of matching the one relevant paragraph.
Chunking (with overlap, so a sentence split across a chunk boundary isn't
lost) keeps each embedding focused on one coherent idea.

## Metadata filtering

Not every retrieval should search *everything*. `retrieve_documents(db,
query, doc_type="resume")` narrows the search to just resume chunks —
useful when the agent knows what *kind* of evidence it needs. See the
`doc_type` parameter threaded through `retriever.py` →
`retrieval_tools.py` → the `retrieve_documents_tool` the agent can call.

## Source attribution

Every `RetrievedChunk` (see `retriever.py`) carries `source`,
`document_id`, `chunk_id`, `content`, and `similarity_score` — never just
raw text. This is what lets a final answer say "based on your resume..."
instead of presenting retrieved content as if the model always knew it.

## EVIDENCE vs CALCULATION vs INTERPRETATION

When the agent answers using retrieved context, it should be possible to
tell apart:

- **EVIDENCE** — text pulled directly from a retrieved chunk (a resume
  bullet point, a company-notes sentence).
- **CALCULATION** — a deterministic result from a tool (e.g.
  `calculate_match_score`'s numeric score).
- **INTERPRETATION** — the LLM's synthesis/explanation connecting the
  two.

This project doesn't tag every sentence of every answer with these
labels (that would make responses hard to read), but the *underlying
data* keeps them separable: `retrieved_context` (evidence) and
`tool_results` (calculation) are both returned alongside `final_answer`
(which mixes in interpretation) from `run_agent()` — see the Streamlit
"RAG" and "Tools" tabs, which show evidence and calculations
side-by-side with the final answer rather than folding everything into
one opaque block of text.

## Never fabricate evidence

If `retrieve_documents_tool` returns no results, it says so explicitly
(`"note": "No matching documents found..."`) rather than returning
nothing and letting the model quietly fill the gap from its own
training data while the user assumes it came from their documents.
