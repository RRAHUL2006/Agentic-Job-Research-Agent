# Learning Path

A suggested order to read this codebase in, building understanding
incrementally rather than jumping straight into the graph.

## 1. Foundations (no agent yet)

1. `app/config.py` — see everything the system can be configured with.
2. `app/db/models.py` — the full schema. Don't memorize it, just skim
   what exists.
3. `app/db/session.py` — how every other module talks to Postgres.
4. Run `docker compose up -d postgres && python -m app.db.init_db` and
   confirm the tables exist (`psql` or any Postgres client).

## 2. The LLM, standalone

1. `app/agent/llm.py` — the only file that talks to Ollama for chat.
2. Try it directly in a Python shell:
   ```python
   from app.agent.llm import get_llm, invoke_with_recovery
   from langchain_core.messages import HumanMessage
   print(invoke_with_recovery(get_llm(), [HumanMessage(content="hi")]).content)
   ```

## 3. RAG, standalone

1. `docs/RAG_GUIDE.md` and `docs/PGVECTOR_GUIDE.md`.
2. `app/retrieval/chunker.py` → `embeddings.py` → `ingest.py` → `retriever.py`, in that order.
3. Run `python -m scripts.seed_demo_data` and then try a retrieval query
   directly:
   ```python
   from app.db.session import session_scope
   from app.retrieval.retriever import retrieve_documents
   with session_scope() as db:
       for c in retrieve_documents(db, "BP interview prep", top_k=3):
           print(c.similarity_score, c.content[:80])
   ```

## 4. Tools, standalone

1. `app/tools/base.py` (the safety wrapper) then any one tool file, e.g.
   `app/tools/analysis_tools.py`.
2. `app/tools/registry.py` — the whitelist every tool must appear in.
3. Call a tool's underlying function directly (bypassing the LLM
   entirely) to see what it returns:
   ```python
   from app.tools.analysis_tools import _calculate_match_score
   print(_calculate_match_score('["python","sql"]', '["python"]'))
   ```

## 5. The graph

1. `docs/LANGGRAPH_GUIDE.md`.
2. `app/graph/state.py` — what flows through the graph.
3. `app/graph/nodes.py` — read top to bottom; each node's docstring
   explains its one job.
4. `app/graph/edges.py` — the two routing decisions that make this a
   graph and not a straight line.
5. `app/graph/graph.py` — see it all wired together; match this file
   against the diagram in `docs/ARCHITECTURE.md`.

## 6. Running the whole thing

1. `app/agent/runtime.py` — the one function everything else calls.
2. `ollama serve` (separate terminal) + `docker compose up -d postgres`
   + `python -m app.db.init_db` + `python -m scripts.seed_demo_data`.
3. `streamlit run app/ui/streamlit_app.py` and have a real conversation.
   Watch the "Agent Graph" and "Tools" tabs after each message — this is
   the fastest way to build intuition for what the graph is actually
   doing.

## 7. Observability & evaluation

1. `app/db/models.py::AgentTrace` and `ToolCall`.
2. `GET /traces/{session_id}` and the Streamlit "Agent Graph" tab.
3. `docs/EVALUATION.md`, then run the evaluation suite and read the
   `evaluations` table.

## 8. Extensions (optional, once everything above makes sense)

1. `app/graph/supervisor.py` — a multi-agent alternative to the
   single-agent graph.
2. Add a checkpointer to `app/graph/graph.py` for pause/resume support
   (see the "Checkpoints" section of `docs/LANGGRAPH_GUIDE.md`).
3. Implement `HttpWebSearchProvider.search()` in `app/tools/web_tools.py`
   against a real search API.

## What you should be able to explain afterward

- Why an agent needs *state*, and how it differs from long-term memory.
- Why tool calling requires your own code to execute the call (the LLM
  never runs anything itself).
- Why RAG needs chunking, not just "embed the whole document."
- Why the graph has two different loops (tool use, and reflection retry)
  and how each is bounded.
- Why PostgreSQL + pgvector instead of a separate vector database.
- What "groundedness" means and how you'd measure it.
