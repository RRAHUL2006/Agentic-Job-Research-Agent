# Agentic Job Research Agent

A production-shaped, teaching-grade agentic AI system: a LangGraph agent
that researches companies, finds jobs, scores skill matches, identifies
gaps, and builds learning plans — backed by PostgreSQL + pgvector for
persistence, memory, and retrieval, running entirely on local
infrastructure (Ollama) with zero required API keys.

> Built as a portfolio/learning project to demonstrate real agentic AI
> architecture — planning, tool calling, stateful execution, conditional
> routing, memory, RAG, reflection, and evaluation — not a chatbot with a
> system prompt.

## Table of contents

- [Problem statement](#problem-statement)
- [Architecture](#architecture)
- [Technology stack](#technology-stack--why-each-piece)
- [Agent workflow](#agent-workflow)
- [RAG workflow](#rag-workflow)
- [Memory architecture](#memory-architecture)
- [Database schema](#database-schema)
- [API](#api)
- [Installation](#installation)
- [Example conversations](#example-conversations)
- [Evaluation](#evaluation)
- [Project structure](#project-structure)
- [Future improvements](#future-improvements)

## Problem statement

Job searching involves several distinct research tasks — understanding a
company, finding relevant openings, judging fit, identifying what to
learn next — that people normally do by hand across many browser tabs.
This project builds an agent that can be asked things like *"Research BP
and tell me what I should prepare for a Data Engineer interview"* and
have it **dynamically** decide which steps and tools that requires,
rather than following one hard-coded script for every request.

## Architecture

```
START → planner → retriever → agent ⇄ tools
                                 │
                            reflection ⇄ (back to agent on FAIL)
                                 │
                             finalizer → END
```

Full breakdown, including why each node exists and how data flows
through the system, in [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

## Technology stack — why each piece

| Technology | Why |
|---|---|
| **LangChain** | Uniform chat-model and tool-calling interface; swapping models later touches one file. |
| **LangGraph** | The workflow needs branches (tool call or not?) and bounded loops (keep using tools; retry failed reflection) — a plain chain can't express that. |
| **PostgreSQL** | Every table here is genuinely relational (sessions, memories, traces, plans) and needs real transactions and concurrent-writer support — not a fit for SQLite. See [`docs/POSTGRESQL_GUIDE.md`](docs/POSTGRESQL_GUIDE.md). |
| **pgvector** | Vector similarity search *inside* the same database as the rest of the app's data — no separate vector DB to run or keep in sync. See [`docs/PGVECTOR_GUIDE.md`](docs/PGVECTOR_GUIDE.md). |
| **Ollama** | Local inference, zero API keys, realistic stand-in for any chat-completions-shaped provider. |
| **FastAPI** | Typed request/response models, auto-generated docs, a clean seam between the agent and any client. |
| **Streamlit** | A visual window into the agent's internals (plan, trace, tool calls, evidence) without building a custom frontend. |

Full concept guides: [`AGENTIC_AI_GUIDE.md`](docs/AGENTIC_AI_GUIDE.md) ·
[`LANGGRAPH_GUIDE.md`](docs/LANGGRAPH_GUIDE.md) ·
[`LANGCHAIN_GUIDE.md`](docs/LANGCHAIN_GUIDE.md)

## Agent workflow

1. **Planner** — breaks the request into a short task list (persisted to `plans`/`tasks`).
2. **Retriever** — one pgvector pass over the raw request before reasoning starts.
3. **Agent** — an LLM bound to 9 tools; decides tool call vs. final answer, dynamically, per request.
4. **Tools** — executes whatever the agent asked for; every call is logged and contained (a failing tool can't crash the graph).
5. *(loop back to Agent until no more tool calls)*
6. **Reflection** — validates the draft answer against the request and evidence; can send it back to Agent (bounded retries).
7. **Finalizer** — guarantees a response, even after partial failure.

## RAG workflow

```
text → chunk_text() → embed_texts() → Postgres (documents + document_chunks)
query → embed_text() → pgvector cosine search → top-K chunks (source-attributed) → LLM
```

Details in [`docs/RAG_GUIDE.md`](docs/RAG_GUIDE.md).

## Memory architecture

- **Short-term**: the running `AgentState` for one request (`app/graph/state.py`).
- **Long-term key/value**: `remember`/`recall` tools → `memories` table — exact facts ("target_role = Data Engineering").
- **Semantic**: `semantic_memories` table (pgvector) — free-text memories found by meaning, not exact key.

## Database schema

13 tables across identity/conversation, memory, RAG, domain data
(jobs/companies), observability (tool_calls/agent_traces), planning
(plans/tasks), and evaluation. Full schema with rationale in
[`docs/POSTGRESQL_GUIDE.md`](docs/POSTGRESQL_GUIDE.md); source of truth
is [`app/db/models.py`](app/db/models.py).

## API

| Endpoint | Purpose |
|---|---|
| `GET /health` | Ollama / Postgres / pgvector status |
| `POST /agent` | Run the agent on a request |
| `POST /memory`, `GET /memory` | Write/read long-term memory |
| `POST /retrieve` | Direct RAG query |
| `GET /traces/{session_id}` | Full execution trace for a session |
| `POST /evaluate` | Run the evaluation suite |
| `GET /jobs`, `GET /companies/{company}` | Browse seeded domain data |

Interactive docs at `http://localhost:8000/docs` once the API is running.

## Installation

### Prerequisites

- Python 3.11+
- Docker Desktop (for PostgreSQL + pgvector)
- [Ollama](https://ollama.com) installed and running on the host machine

### 1. Pull the models (Windows, macOS, Linux — same commands)

```bash
ollama pull llama3.1:8b
ollama pull nomic-embed-text
```

### 2. Set up Python

**Windows (PowerShell):**
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
```

**macOS / Linux:**
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

### 3. Start PostgreSQL + pgvector

```bash
docker compose up -d postgres
```

### 4. Initialize the database and load demo data

```bash
python -m app.db.init_db
python -m scripts.seed_demo_data
```

### 5. Run it

```bash
# Terminal 1
uvicorn app.api.main:app --reload

# Terminal 2
streamlit run app/ui/streamlit_app.py
```

Open `http://localhost:8501` for the dashboard, `http://localhost:8000/docs` for the API.

### Alternative: full Docker Compose

```bash
docker compose up -d --build
```

Runs Postgres + the API + the UI in containers (Ollama still runs on the
host — see the comment in `docker-compose.yml` for why, and how the
containers reach it via `host.docker.internal`).

### Running tests

```bash
pytest
```

Tests that need Postgres/Ollama auto-skip with a clear reason if those
services aren't reachable — see `tests/conftest.py`.

## Example conversations

> *"Find Data Engineer jobs matching my skills."*
> → planner breaks this into search + match steps → agent calls
> `search_jobs`, then (once it has the user's skills via `recall`)
> `calculate_match_score` → answer lists ranked matches with transparent
> matched/missing skills.

> *"Research BP and tell me what I should prepare for a Data Engineer
> interview."*
> → agent calls `get_company_info`, then `retrieve_documents_tool` against
> ingested company notes, then `search_jobs` for BP-specific postings →
> answer grounds interview prep advice in retrieved evidence with source
> attribution.

> *"Remember that I prefer Data Engineering roles."* → *(new session)*
> *"What role did I say I prefer?"*
> → `remember` writes to both `memories` and `semantic_memories`; `recall`
> in the second conversation retrieves it by exact key match.

## Evaluation

11 end-to-end tasks (job search, company research, memory round-trip,
skill-gap analysis, learning-plan generation, multi-job comparison,
unknown-company handling, simulated tool failure) scored on success rate,
tool-selection accuracy, groundedness, latency, and step count. Run via
`POST /evaluate` or the Streamlit Evaluation tab — results persist to the
`evaluations` table, so you can track trends across prompt/config
changes over time. Details in [`docs/EVALUATION.md`](docs/EVALUATION.md).

*(Run the suite yourself and paste your numbers here for your portfolio —
results depend on which Ollama model you're running.)*

## Project structure

```
app/
  agent/       llm.py, runtime.py
  graph/       state.py, nodes.py, edges.py, graph.py, supervisor.py (optional)
  tools/       base.py, registry.py, job/company/memory/retrieval/analysis/web tools
  retrieval/   ingest.py, chunker.py, embeddings.py, retriever.py, documents.py
  db/          session.py, models.py, init_db.py
  models/      schemas.py
  api/         main.py
  ui/          streamlit_app.py
  evaluation/  evaluator.py, datasets.py, metrics.py
data/          profile.json, jobs.json, companies.json, knowledge/*.md
docs/          nine concept guides — start with LEARNING_PATH.md
tests/         one file per subsystem
scripts/       seed_demo_data.py
```

## Screenshots

*(Add screenshots of the Streamlit Chat, Agent Graph, and Evaluation tabs
here for your portfolio — capture them after running through
`docs/LEARNING_PATH.md` step 6.)*

## Future improvements

- Real web search provider (`app/tools/web_tools.py::HttpWebSearchProvider` is stubbed and ready to wire up).
- LangGraph checkpointer for pause/resume and true human-in-the-loop approval.
- Parallel (rather than sequential) specialist agents in `app/graph/supervisor.py`.
- LLM-as-judge groundedness scoring instead of the current substring-overlap proxy.
- Streaming responses (token-by-token) instead of waiting for the full graph run.
- Authentication on the FastAPI layer for anything beyond local/demo use.
