-- Runs automatically on first container start (mounted into
-- /docker-entrypoint-initdb.d by docker-compose.yml).
-- app/db/init_db.py also calls this defensively, so it's safe either way.
CREATE EXTENSION IF NOT EXISTS vector;
