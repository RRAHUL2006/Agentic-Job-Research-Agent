# Demo Candidate — Resume Summary

## Skills
Python, SQL, PostgreSQL, Pandas, Docker, AWS (S3, Lambda), ETL pipeline design.

## Experience
2 years as a backend engineer building REST APIs and batch data jobs.
Migrated a nightly reporting job from cron scripts to an orchestrated
pipeline, reducing failures by half.

## Interests
Moving into data engineering specifically: pipeline orchestration
(Airflow), streaming (Kafka), and cloud data warehousing (Snowflake or
BigQuery).
