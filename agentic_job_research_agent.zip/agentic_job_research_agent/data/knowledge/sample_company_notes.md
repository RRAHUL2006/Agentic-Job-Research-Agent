# BP — Interview Prep Notes

BP is a global energy company investing in cloud data platforms to
support decarbonization initiatives. Data Engineering roles typically
emphasize:

- Python and SQL fluency
- Building and maintaining ETL/ELT pipelines (Airflow, Spark)
- Cloud data warehousing (Snowflake, AWS)
- Working with large, messy operational datasets from energy assets

Likely interview themes: pipeline design trade-offs, handling schema
drift, and communicating data quality issues to non-technical
stakeholders.
