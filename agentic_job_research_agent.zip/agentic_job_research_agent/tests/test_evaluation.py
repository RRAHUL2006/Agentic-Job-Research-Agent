"""
tests/test_evaluation.py
----------------------------
Pure-logic tests for app/evaluation/metrics.py. The full evaluation suite
(app/evaluation/evaluator.py) exercises the live agent end-to-end and is
better run manually via `POST /evaluate` or the Streamlit Evaluation tab
than as a fast unit test.
"""
from app.evaluation.metrics import (
    groundedness_score,
    keyword_success,
    recovered_gracefully,
    tool_selection_correct,
)


def test_tool_selection_correct_true():
    assert tool_selection_correct("search_jobs", [{"tool_name": "search_jobs"}]) is True


def test_tool_selection_correct_false():
    assert tool_selection_correct("search_jobs", [{"tool_name": "recall"}]) is False


def test_tool_selection_correct_none_when_not_expected():
    assert tool_selection_correct(None, []) is None


def test_keyword_success_all_keywords_present():
    assert keyword_success("I found Data Engineer jobs for you.", ["data engineer"]) is True


def test_keyword_success_missing_keyword():
    assert keyword_success("I found some jobs.", ["data engineer"]) is False


def test_keyword_success_no_keywords_requires_nonempty_answer():
    assert keyword_success("anything", []) is True
    assert keyword_success(None, []) is False


def test_groundedness_score_no_evidence_returns_none():
    assert groundedness_score("some answer", []) is None


def test_groundedness_score_empty_answer_is_zero():
    evidence = [{"content": "Some evidence chunk here."}]
    assert groundedness_score(None, evidence) == 0.0


def test_recovered_gracefully_only_applies_to_simulated_failures():
    assert recovered_gracefully(False, ["err"], "answer") is None


def test_recovered_gracefully_true_when_error_and_answer_present():
    assert recovered_gracefully(True, ["tool failed"], "here's what I could do") is True


def test_recovered_gracefully_false_when_no_answer():
    assert recovered_gracefully(True, ["tool failed"], None) is False
