"""
tests/test_memory.py
------------------------
Tests app/tools/memory_tools.py's remember/recall against a real Postgres
instance. Marked needs_postgres (and needs_ollama for the semantic path,
since `remember` tries to embed the text).
"""
import uuid

import pytest


@pytest.mark.needs_postgres
def test_remember_rejects_invalid_user_id():
    from app.tools.memory_tools import _remember

    result = _remember(user_id="not-a-uuid", memory_key="k", memory_value="v")
    assert "error" in result


@pytest.mark.needs_postgres
def test_remember_and_recall_exact_key():
    from app.db.models import User
    from app.db.session import session_scope
    from app.tools.memory_tools import _recall, _remember

    with session_scope() as db:
        user = User(email=f"test-{uuid.uuid4().hex[:8]}@example.com")
        db.add(user)
        db.flush()
        user_id = str(user.id)

    remember_result = _remember(user_id=user_id, memory_key="target_role", memory_value="Data Engineering")
    assert remember_result["stored"] is True

    recall_result = _recall(user_id=user_id, query="target_role")
    exact_values = [m["value"] for m in recall_result["exact_matches"]]
    assert "Data Engineering" in exact_values


@pytest.mark.needs_postgres
def test_remember_upserts_existing_key():
    from app.db.models import Memory, User
    from app.db.session import session_scope
    from app.tools.memory_tools import _remember

    with session_scope() as db:
        user = User(email=f"test-{uuid.uuid4().hex[:8]}@example.com")
        db.add(user)
        db.flush()
        user_id = str(user.id)

    _remember(user_id=user_id, memory_key="preferred_location", memory_value="India")
    _remember(user_id=user_id, memory_key="preferred_location", memory_value="Remote")

    with session_scope() as db:
        rows = db.query(Memory).filter_by(user_id=uuid.UUID(user_id), memory_key="preferred_location").all()
    assert len(rows) == 1
    assert rows[0].memory_value == "Remote"
