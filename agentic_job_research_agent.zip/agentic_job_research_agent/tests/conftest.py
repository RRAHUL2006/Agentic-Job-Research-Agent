"""
tests/conftest.py
--------------------
Shared fixtures. Tests that need Postgres/Ollama are marked and skipped
automatically if those services aren't reachable, so `pytest` still gives
a useful signal on a machine that only has Python installed (e.g. CI
running unit-level tests, or a student who hasn't started Docker yet).
"""
from __future__ import annotations

import pytest
from sqlalchemy import text

from app.db.session import engine


def _postgres_reachable() -> bool:
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return True
    except Exception:  # noqa: BLE001
        return False


def _ollama_reachable() -> bool:
    try:
        from app.agent.llm import get_llm, invoke_with_recovery

        invoke_with_recovery(get_llm(), [])
        return True
    except Exception:  # noqa: BLE001
        return False


@pytest.fixture(scope="session")
def postgres_available() -> bool:
    return _postgres_reachable()


@pytest.fixture(scope="session")
def ollama_available() -> bool:
    return _ollama_reachable()


def pytest_collection_modifyitems(config, items):
    """Auto-skip tests marked `needs_postgres` / `needs_ollama` when unavailable."""
    skip_pg = pytest.mark.skip(reason="Postgres not reachable — start it with `docker compose up -d postgres`")
    skip_ollama = pytest.mark.skip(reason="Ollama not reachable — start it with `ollama serve`")
    pg_ok = _postgres_reachable()
    ollama_ok = _ollama_reachable()
    for item in items:
        if "needs_postgres" in item.keywords and not pg_ok:
            item.add_marker(skip_pg)
        if "needs_ollama" in item.keywords and not ollama_ok:
            item.add_marker(skip_ollama)
