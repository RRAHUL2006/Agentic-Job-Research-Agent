"""
tests/test_retrieval.py
---------------------------
Chunker tests run everywhere (pure logic). Retrieval tests need a live
Postgres+pgvector and a running Ollama embedding model, so they're marked
and auto-skipped when those aren't available (see tests/conftest.py).
"""
import uuid

import pytest

from app.retrieval.chunker import chunk_text


def test_chunk_text_empty_returns_empty_list():
    assert chunk_text("") == []
    assert chunk_text("   ") == []


def test_chunk_text_respects_chunk_size():
    text = "word " * 1000
    chunks = chunk_text(text, chunk_size=200, overlap=50)
    assert all(len(c) <= 200 + 50 for c in chunks)  # allow slack for boundary rounding
    assert len(chunks) > 1


def test_chunk_text_rejects_overlap_gte_chunk_size():
    with pytest.raises(ValueError):
        chunk_text("some text", chunk_size=100, overlap=100)


def test_chunk_text_short_text_single_chunk():
    chunks = chunk_text("A short paragraph.", chunk_size=800, overlap=150)
    assert len(chunks) == 1


@pytest.mark.needs_postgres
@pytest.mark.needs_ollama
def test_ingest_and_retrieve_roundtrip():
    from app.db.session import session_scope
    from app.retrieval.ingest import ingest_text
    from app.retrieval.retriever import retrieve_documents

    marker = uuid.uuid4().hex[:8]
    with session_scope() as db:
        ingest_text(
            db,
            text=f"This document is about kubernetes orchestration. marker-{marker}.",
            title=f"test-doc-{marker}",
            doc_type="test",
            source="unit-test",
        )

    with session_scope() as db:
        results = retrieve_documents(db, "kubernetes orchestration", top_k=3, doc_type="test")
    assert any(marker in r.content for r in results)
