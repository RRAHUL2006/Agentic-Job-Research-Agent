"""
tests/test_tools.py
-----------------------
Pure-logic tool tests — no Postgres or Ollama required. These exercise
calculate_match_score, create_learning_plan, extract_job_requirements,
and rank_jobs directly (bypassing the LangChain @tool wrapper's
`.invoke()` to test the underlying functions in isolation).
"""
import json

from app.tools.analysis_tools import _calculate_match_score, _create_learning_plan
from app.tools.job_tools import _extract_job_requirements, _rank_jobs


def test_calculate_match_score_exact_and_missing():
    result = _calculate_match_score(
        job_skills_json=json.dumps(["python", "sql", "airflow"]),
        user_skills_json=json.dumps(["python", "sql"]),
    )
    assert result["matched_skills"] == ["python", "sql"]
    assert result["missing_skills"] == ["airflow"]
    assert 0 < result["score"] < 1


def test_calculate_match_score_partial_match():
    result = _calculate_match_score(
        job_skills_json=json.dumps(["sql"]),
        user_skills_json=json.dumps(["postgresql"]),
    )
    assert result["partial_matches"]
    assert result["partial_matches"][0]["required"] == "sql"


def test_calculate_match_score_invalid_json():
    result = _calculate_match_score(job_skills_json="not json", user_skills_json="[]")
    assert "error" in result


def test_create_learning_plan_orders_foundational_skills_first():
    result = _create_learning_plan(json.dumps(["airflow", "python", "spark"]))
    skills_in_order = [item["skill"] for item in result["plan"]]
    assert skills_in_order.index("python") < skills_in_order.index("airflow")


def test_create_learning_plan_empty_input():
    result = _create_learning_plan(json.dumps([]))
    assert result["plan"] == []


def test_extract_job_requirements_finds_known_skills():
    description = "We need someone with 3+ years of Python, SQL, and Airflow experience."
    result = _extract_job_requirements(description)
    assert "python" in result["skills"]
    assert "sql" in result["skills"]
    assert result["min_years_experience"] == 3


def test_extract_job_requirements_empty_input():
    result = _extract_job_requirements("")
    assert "error" in result


def test_rank_jobs_orders_by_score_desc():
    jobs = json.dumps(
        [
            {"title": "Job A", "required_skills": ["python", "sql", "spark"]},
            {"title": "Job B", "required_skills": ["python"]},
        ]
    )
    user_skills = json.dumps(["python"])
    result = _rank_jobs(jobs, user_skills)
    scores = [j["score"] for j in result["ranked_jobs"]]
    assert scores == sorted(scores, reverse=True)


def test_rank_jobs_invalid_json():
    result = _rank_jobs("not json", "[]")
    assert "error" in result
