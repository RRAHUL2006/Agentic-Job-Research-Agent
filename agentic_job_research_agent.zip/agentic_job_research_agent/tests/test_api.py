"""
tests/test_api.py
---------------------
Exercises the FastAPI app with TestClient. /health works with no external
services and should always return a response (degraded status is fine,
crashing is not). The rest require Postgres/Ollama and are marked
accordingly.
"""
import pytest
from fastapi.testclient import TestClient

from app.api.main import app

client = TestClient(app)


def test_health_endpoint_never_crashes():
    response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] in {"ok", "degraded"}


@pytest.mark.needs_postgres
def test_jobs_endpoint_returns_list_shape():
    response = client.get("/jobs")
    assert response.status_code == 200
    assert "jobs" in response.json()


@pytest.mark.needs_postgres
def test_company_endpoint_404_for_unknown_company():
    response = client.get("/companies/Definitely-Not-A-Real-Company-Xyz")
    assert response.status_code == 404


@pytest.mark.needs_postgres
def test_memory_write_requires_valid_uuid():
    response = client.post(
        "/memory", json={"user_id": "not-a-uuid", "memory_key": "k", "memory_value": "v"}
    )
    assert response.status_code == 400


@pytest.mark.needs_postgres
@pytest.mark.needs_ollama
def test_agent_endpoint_full_roundtrip():
    response = client.post("/agent", json={"user_request": "Remember that I like Python."})
    assert response.status_code == 200
    body = response.json()
    assert body["answer"] is not None
    assert "session_id" in body
