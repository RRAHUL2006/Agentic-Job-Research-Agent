"""
tests/test_graph.py
-----------------------
Tests the conditional routing functions in app/graph/edges.py directly
with hand-built state dicts — no LLM or DB calls needed, since these
functions are pure `state -> str` logic.
"""
from langchain_core.messages import AIMessage

from app.config import settings
from app.graph.edges import route_after_agent, route_after_reflection


class _FakeAIMessageNoTools(AIMessage):
    pass


def test_route_after_agent_goes_to_tools_when_tool_calls_present():
    state = {
        "step_count": 1,
        "messages": [
            AIMessage(content="", tool_calls=[{"name": "search_jobs", "args": {}, "id": "1"}]),
        ],
    }
    assert route_after_agent(state) == "tools"


def test_route_after_agent_goes_to_reflection_when_no_tool_calls():
    state = {"step_count": 1, "messages": [AIMessage(content="final answer")]}
    assert route_after_agent(state) == "reflection"


def test_route_after_agent_stops_looping_at_max_steps():
    state = {
        "step_count": settings.max_agent_steps,
        "messages": [AIMessage(content="", tool_calls=[{"name": "search_jobs", "args": {}, "id": "1"}])],
    }
    # Even though a tool call is present, we must not loop past the step cap.
    assert route_after_agent(state) == "reflection"


def test_route_after_reflection_passed_goes_to_finalizer():
    assert route_after_reflection({"reflection_passed": True}) == "finalizer"


def test_route_after_reflection_failed_goes_back_to_agent():
    assert route_after_reflection({"reflection_passed": False}) == "agent"


def test_route_after_reflection_default_is_finalizer():
    # Missing key defaults to True (see edges.py) — fail-open rather than
    # fail-closed, so a bug elsewhere can't strand a user in an infinite loop.
    assert route_after_reflection({}) == "finalizer"
