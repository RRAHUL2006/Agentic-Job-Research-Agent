"""
scripts/seed_demo_data.py
-----------------------------
WHAT: Loads data/jobs.json and data/companies.json into Postgres, and
      ingests data/knowledge/*.md through the RAG pipeline (so the RAG tab
      and retrieve_documents tool have something to find immediately).
WHY:  A brand-new checkout otherwise has an empty database — this script
      gives a new learner something to query on their very first run.

Run with:  python -m scripts.seed_demo_data
(after:    python -m app.db.init_db)
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent.parent / "data"

from app.db.models import Company, Job, User  # noqa: E402
from app.db.session import session_scope  # noqa: E402
from app.retrieval.ingest import IngestError, ingest_text  # noqa: E402


def seed_companies_and_jobs() -> None:
    companies = json.loads((DATA_DIR / "companies.json").read_text())
    jobs = json.loads((DATA_DIR / "jobs.json").read_text())

    with session_scope() as db:
        for c in companies:
            if not db.query(Company).filter_by(name=c["name"]).first():
                db.add(Company(name=c["name"], industry=c.get("industry"), summary=c.get("summary")))

        for j in jobs:
            exists = db.query(Job).filter_by(title=j["title"], company_name=j["company_name"]).first()
            if not exists:
                db.add(
                    Job(
                        title=j["title"],
                        company_name=j["company_name"],
                        location=j.get("location"),
                        description=j["description"],
                        required_skills=j.get("required_skills", []),
                        preferred_skills=j.get("preferred_skills", []),
                    )
                )
    print(f"[seed] Loaded {len(companies)} companies, {len(jobs)} jobs.")


def seed_documents() -> None:
    demo_user_id = None
    with session_scope() as db:
        demo = db.query(User).filter_by(email="demo@example.com").first()
        demo_user_id = demo.id if demo else None

    knowledge_dir = DATA_DIR / "knowledge"
    for path in sorted(knowledge_dir.glob("*.md")):
        doc_type = "resume" if "resume" in path.stem else "company_profile"
        with session_scope() as db:
            try:
                ingest_text(
                    db,
                    text=path.read_text(),
                    title=path.stem.replace("_", " ").title(),
                    doc_type=doc_type,
                    source=str(path),
                    user_id=demo_user_id,
                )
                print(f"[seed] Ingested {path.name} as {doc_type}.")
            except IngestError as exc:
                print(f"[seed] Skipped {path.name}: {exc}", file=sys.stderr)


def main() -> None:
    seed_companies_and_jobs()
    try:
        seed_documents()
    except Exception as exc:  # noqa: BLE001
        print(
            f"[seed] Document ingestion failed (is Ollama running with the embedding "
            f"model pulled?): {exc}",
            file=sys.stderr,
        )


if __name__ == "__main__":
    main()
