"""
app/models/schemas.py
------------------------
WHAT: Pydantic request/response models for every FastAPI endpoint.
WHY:  Keeps validation and API documentation (FastAPI auto-generates
      OpenAPI docs from these) separate from both the ORM models
      (app/db/models.py) and the LangGraph state (app/graph/state.py) —
      three different concerns that shouldn't share one class.
"""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class AgentRequest(BaseModel):
    user_request: str = Field(..., min_length=1, description="The user's natural-language request.")
    user_id: str | None = Field(default=None, description="Existing user UUID; omit to use the demo user.")
    session_id: str | None = Field(default=None, description="Existing session UUID; omit to start a new session.")


class AgentResponse(BaseModel):
    session_id: str
    user_id: str
    answer: str | None
    plan: list[dict]
    events: list[dict]
    tool_results: list[dict]
    retrieved_context: list[dict]
    errors: list[str]
    step_count: int


class MemoryWriteRequest(BaseModel):
    user_id: str
    memory_key: str
    memory_value: str


class MemoryReadResponse(BaseModel):
    memories: list[dict[str, Any]]


class RetrieveRequest(BaseModel):
    query: str
    top_k: int = 5
    doc_type: str | None = None


class RetrieveResponse(BaseModel):
    results: list[dict[str, Any]]


class EvaluateRequest(BaseModel):
    task_name: str | None = Field(default=None, description="Run one named task; omit to run the full suite.")


class HealthResponse(BaseModel):
    status: str
    ollama: str
    postgres: str
    pgvector: str
