"""
app/agent/runtime.py
-----------------------
WHAT: `run_agent()` — the single function FastAPI and Streamlit both call.
      Ensures a session exists, builds the initial AgentState, invokes the
      compiled LangGraph, persists the exchange, and returns a plain dict
      response.
WHY:  Neither the API layer nor the UI layer should know anything about
      LangGraph internals — they call one function and get back
      {answer, plan, events, tool_results, errors}.
"""
from __future__ import annotations

import uuid

from app.db.models import ChatSession, Message, User
from app.db.session import session_scope
from app.graph.graph import compiled_graph


def _ensure_user(db, user_id: str | None) -> uuid.UUID:
    if user_id:
        try:
            uid = uuid.UUID(user_id)
            if db.get(User, uid):
                return uid
        except ValueError:
            pass
    # Fall back to (or create) the seeded demo user — see app/db/init_db.py.
    demo = db.query(User).filter_by(email="demo@example.com").first()
    if not demo:
        demo = User(email="demo@example.com", display_name="Demo User")
        db.add(demo)
        db.flush()
    return demo.id


def _ensure_session(db, session_id: str | None, user_id: uuid.UUID) -> uuid.UUID:
    if session_id:
        try:
            sid = uuid.UUID(session_id)
            if db.get(ChatSession, sid):
                return sid
        except ValueError:
            pass
    session = ChatSession(user_id=user_id)
    db.add(session)
    db.flush()
    return session.id


def run_agent(user_request: str, *, user_id: str | None = None, session_id: str | None = None) -> dict:
    with session_scope() as db:
        uid = _ensure_user(db, user_id)
        sid = _ensure_session(db, session_id, uid)
        db.add(Message(session_id=sid, role="user", content=user_request))
        uid_str, sid_str = str(uid), str(sid)

    initial_state = {
        "session_id": sid_str,
        "user_id": uid_str,
        "user_request": user_request,
        "messages": [],
        "errors": [],
        "events": [],
        "step_count": 0,
        "reflection_retries": 0,
        "tool_results": [],
        "retrieved_context": [],
        "approval_required": False,
    }

    final_state = compiled_graph.invoke(initial_state)

    with session_scope() as db:
        db.add(Message(session_id=sid, role="assistant", content=final_state.get("final_answer") or ""))

    return {
        "session_id": sid_str,
        "user_id": uid_str,
        "answer": final_state.get("final_answer"),
        "plan": final_state.get("plan", []),
        "events": final_state.get("events", []),
        "tool_results": final_state.get("tool_results", []),
        "retrieved_context": final_state.get("retrieved_context", []),
        "errors": final_state.get("errors", []),
        "step_count": final_state.get("step_count", 0),
    }
