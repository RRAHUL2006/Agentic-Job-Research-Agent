"""
app/agent/llm.py
-----------------
WHAT: Builds the single ChatOllama instance every other part of the system
      uses, and wraps `.invoke()` with retry + timeout + friendly errors.
WHY:  If we let each module construct its own ChatOllama, config drifts
      (different temperature here, different model there). One factory,
      one place to change defaults.
IN:   app.config.settings (model name, base url, temperature, timeout).
OUT:  `get_llm()` -> a LangChain ChatOllama bound to whatever tools you
      pass it; `invoke_with_recovery()` -> a safe call wrapper used by the
      agent node.

Concept this file teaches: an LLM is just a function
    (messages, tools) -> AIMessage
LangChain gives us a consistent object for that function regardless of
which model provider sits behind it. Swapping Ollama for OpenAI later is
(ideally) a one-line change here and nowhere else.
"""
from __future__ import annotations

import logging
from functools import lru_cache
from typing import Any, Sequence

from langchain_core.messages import BaseMessage
from langchain_core.tools import BaseTool
from langchain_ollama import ChatOllama
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_fixed

from app.config import settings

logger = logging.getLogger(__name__)


class LLMUnavailableError(RuntimeError):
    """Raised when Ollama cannot be reached or times out after retries."""


@lru_cache
def _base_llm() -> ChatOllama:
    return ChatOllama(
        base_url=settings.ollama_base_url,
        model=settings.ollama_model,
        temperature=settings.ollama_temperature,
        timeout=settings.ollama_request_timeout,
    )


def get_llm(tools: Sequence[BaseTool] | None = None) -> ChatOllama:
    """
    Returns the shared ChatOllama instance, optionally bound to a set of
    LangChain tools so the model can emit tool_calls.
    """
    llm = _base_llm()
    if tools:
        llm = llm.bind_tools(list(tools))
    return llm


@retry(
    reraise=True,
    stop=stop_after_attempt(3),
    wait=wait_fixed(2),
    retry=retry_if_exception_type((TimeoutError, ConnectionError)),
)
def _invoke(llm: ChatOllama, messages: Sequence[BaseMessage]) -> Any:
    return llm.invoke(list(messages))


def invoke_with_recovery(llm: ChatOllama, messages: Sequence[BaseMessage]) -> BaseMessage:
    """
    Calls the LLM with a small retry budget for transient network errors.
    Raises LLMUnavailableError (a clean, catchable type) if Ollama is truly
    down, so the graph's error-recovery path (see app/graph/nodes.py) can
    degrade gracefully instead of crashing the whole request.
    """
    try:
        return _invoke(llm, messages)
    except Exception as exc:  # noqa: BLE001 - we deliberately widen then re-raise typed
        logger.error("LLM call failed after retries: %s", exc)
        raise LLMUnavailableError(
            f"Could not reach Ollama at {settings.ollama_base_url} "
            f"(model={settings.ollama_model}): {exc}"
        ) from exc
