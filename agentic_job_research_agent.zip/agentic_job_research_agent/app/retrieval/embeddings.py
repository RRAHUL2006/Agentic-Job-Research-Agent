"""
app/retrieval/embeddings.py
----------------------------
WHAT: Turns text into vectors using Ollama's embedding endpoint.
WHY:  Every piece of RAG and semantic memory needs the SAME embedding
      function for both writing (indexing) and reading (querying) —
      vectors from different models aren't comparable. Centralizing it
      here guarantees that.
IN:   str or list[str].
OUT:  list[float] (single embedding) or list[list[float]] (batch), each of
      length settings.embedding_dim.
"""
from __future__ import annotations

import logging
from functools import lru_cache

from langchain_ollama import OllamaEmbeddings

from app.config import settings

logger = logging.getLogger(__name__)


class EmbeddingUnavailableError(RuntimeError):
    """Raised when the embedding model can't be reached."""


@lru_cache
def _embedder() -> OllamaEmbeddings:
    return OllamaEmbeddings(base_url=settings.ollama_base_url, model=settings.embedding_model)


def embed_text(text: str) -> list[float]:
    """Embed a single string. Returns a vector of length settings.embedding_dim."""
    try:
        return _embedder().embed_query(text)
    except Exception as exc:  # noqa: BLE001
        logger.error("Embedding failed: %s", exc)
        raise EmbeddingUnavailableError(
            f"Could not embed text using model={settings.embedding_model} "
            f"at {settings.ollama_base_url}: {exc}"
        ) from exc


def embed_texts(texts: list[str]) -> list[list[float]]:
    """Batch embed. More efficient than calling embed_text in a loop."""
    if not texts:
        return []
    try:
        return _embedder().embed_documents(texts)
    except Exception as exc:  # noqa: BLE001
        logger.error("Batch embedding failed: %s", exc)
        raise EmbeddingUnavailableError(
            f"Could not embed {len(texts)} texts using model={settings.embedding_model}: {exc}"
        ) from exc
