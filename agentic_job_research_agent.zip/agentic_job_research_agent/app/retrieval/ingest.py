"""
app/retrieval/ingest.py
--------------------------
WHAT: The full RAG ingestion pipeline: raw text -> chunks -> embeddings ->
      Postgres/pgvector rows.
WHY:  Every document type (resume, company profile, job description,
      interview notes, learning resources) goes through the exact same
      four steps. One function, called with different `doc_type` values,
      instead of four near-duplicate pipelines.
IN:   text, title, doc_type, source, optional user_id/metadata.
OUT:  The created Document row (with its chunks already persisted).

    text
      ↓
    chunk_text()          (app/retrieval/chunker.py)
      ↓
    embed_texts()          (app/retrieval/embeddings.py)
      ↓
    create_document() + add_chunks()   (app/retrieval/documents.py)
"""
from __future__ import annotations

import logging
import uuid

from sqlalchemy.orm import Session

from app.db.models import Document
from app.retrieval.chunker import chunk_text
from app.retrieval.documents import add_chunks, create_document
from app.retrieval.embeddings import EmbeddingUnavailableError, embed_texts

logger = logging.getLogger(__name__)


class IngestError(RuntimeError):
    pass


def ingest_text(
    db: Session,
    *,
    text: str,
    title: str,
    doc_type: str,
    source: str,
    user_id: uuid.UUID | None = None,
    metadata: dict | None = None,
) -> Document:
    if not text or not text.strip():
        raise IngestError(f"Refusing to ingest empty document: {title!r}")

    chunks = chunk_text(text)
    if not chunks:
        raise IngestError(f"Chunking produced zero chunks for: {title!r}")

    try:
        embeddings = embed_texts(chunks)
    except EmbeddingUnavailableError as exc:
        raise IngestError(f"Embedding failed during ingest of {title!r}: {exc}") from exc

    doc = create_document(
        db,
        title=title,
        doc_type=doc_type,
        source=source,
        user_id=user_id,
        metadata=metadata,
    )
    add_chunks(
        db,
        document_id=doc.id,
        chunks=chunks,
        embeddings=embeddings,
        metadata={"doc_type": doc_type},
    )
    logger.info("Ingested %s (%s) as %d chunks", title, doc_type, len(chunks))
    return doc
