"""
app/retrieval/documents.py
-----------------------------
WHAT: Thin data-access layer for the `documents` / `document_chunks` tables.
WHY:  Keeps SQLAlchemy queries out of ingest.py and retriever.py so those
      files can focus on their actual logic (chunking/embedding, and
      similarity search) instead of ORM plumbing.
"""
from __future__ import annotations

import uuid

from sqlalchemy.orm import Session

from app.db.models import Document, DocumentChunk


def create_document(
    db: Session,
    *,
    title: str,
    doc_type: str,
    source: str,
    user_id: uuid.UUID | None = None,
    metadata: dict | None = None,
) -> Document:
    doc = Document(
        title=title,
        doc_type=doc_type,
        source=source,
        user_id=user_id,
        doc_metadata=metadata or {},
    )
    db.add(doc)
    db.flush()  # get doc.id without a full commit
    return doc


def add_chunks(
    db: Session,
    *,
    document_id: uuid.UUID,
    chunks: list[str],
    embeddings: list[list[float]],
    metadata: dict | None = None,
) -> list[DocumentChunk]:
    if len(chunks) != len(embeddings):
        raise ValueError("chunks and embeddings must be the same length")

    rows = [
        DocumentChunk(
            document_id=document_id,
            chunk_index=i,
            content=chunk,
            embedding=embedding,
            chunk_metadata=metadata or {},
        )
        for i, (chunk, embedding) in enumerate(zip(chunks, embeddings))
    ]
    db.add_all(rows)
    db.flush()
    return rows


def get_document(db: Session, document_id: uuid.UUID) -> Document | None:
    return db.get(Document, document_id)


def list_documents(db: Session, doc_type: str | None = None) -> list[Document]:
    q = db.query(Document)
    if doc_type:
        q = q.filter(Document.doc_type == doc_type)
    return q.order_by(Document.created_at.desc()).all()
