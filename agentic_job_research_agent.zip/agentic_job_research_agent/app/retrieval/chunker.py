"""
app/retrieval/chunker.py
--------------------------
WHAT: Splits long text into overlapping chunks small enough to embed and
      retrieve meaningfully.
WHY:  Embedding an entire resume or job description as one vector loses
      granularity — a query about "SQL experience" should match the one
      paragraph that mentions SQL, not compete against the whole document
      averaged together. Overlap prevents losing context at chunk
      boundaries (e.g. a sentence split mid-thought).
IN:   Raw text + chunk size/overlap (characters, kept simple on purpose —
      a token-based splitter is a drop-in upgrade later).
OUT:  list[str] chunks, in order.
"""
from __future__ import annotations

DEFAULT_CHUNK_SIZE = 800
DEFAULT_OVERLAP = 150


def chunk_text(
    text: str,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    overlap: int = DEFAULT_OVERLAP,
) -> list[str]:
    """
    Simple, dependency-free sliding-window chunker on paragraphs first,
    falling back to hard character windows for any oversized paragraph.
    """
    text = text.strip()
    if not text:
        return []

    if overlap >= chunk_size:
        raise ValueError("overlap must be smaller than chunk_size")

    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    chunks: list[str] = []
    buffer = ""

    def flush():
        if buffer.strip():
            chunks.append(buffer.strip())

    for para in paragraphs:
        if len(para) > chunk_size:
            # Oversized paragraph: flush what we have, then hard-window this one.
            flush()
            buffer = ""
            start = 0
            while start < len(para):
                end = start + chunk_size
                chunks.append(para[start:end].strip())
                start = end - overlap
            continue

        candidate = f"{buffer}\n\n{para}" if buffer else para
        if len(candidate) <= chunk_size:
            buffer = candidate
        else:
            flush()
            buffer = para

    flush()
    return chunks
