"""
app/retrieval/retriever.py
-----------------------------
WHAT: Runs top-K cosine-similarity search over document_chunks (and a
      separate helper for semantic_memories), with optional metadata
      filtering (doc_type).
WHY:  This is the "R" in RAG:  query -> embedding -> pgvector -> top K
      chunks -> evidence handed to the LLM. Isolating it here means the
      graph node that calls it doesn't need to know anything about SQL or
      pgvector operators.
IN:   A query string, a SQLAlchemy session, top_k, optional doc_type filter.
OUT:  list[RetrievedChunk] — each carries source, document_id, chunk_id,
      content, similarity score, and metadata, exactly as required by the
      spec so downstream code can do source attribution.

pgvector concept: `embedding <=> query_embedding` is the COSINE DISTANCE
operator (0 = identical direction, 2 = opposite). We convert to a
similarity score (1 - distance) because "higher is more similar" is more
intuitive to display than "lower is more different".
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.models import Document, DocumentChunk, SemanticMemory
from app.retrieval.embeddings import EmbeddingUnavailableError, embed_text


@dataclass
class RetrievedChunk:
    source: str
    document_id: str
    chunk_id: str
    content: str
    similarity_score: float
    metadata: dict = field(default_factory=dict)


class RetrievalError(RuntimeError):
    pass


def retrieve_documents(
    db: Session,
    query: str,
    *,
    top_k: int = 5,
    doc_type: str | None = None,
    min_similarity: float = 0.0,
) -> list[RetrievedChunk]:
    """Top-K similarity search over document_chunks, optionally filtered by doc_type."""
    try:
        query_embedding = embed_text(query)
    except EmbeddingUnavailableError as exc:
        raise RetrievalError(f"Could not embed query for retrieval: {exc}") from exc

    stmt = (
        select(
            DocumentChunk,
            Document,
            DocumentChunk.embedding.cosine_distance(query_embedding).label("distance"),
        )
        .join(Document, Document.id == DocumentChunk.document_id)
        .order_by("distance")
        .limit(top_k)
    )
    if doc_type:
        stmt = stmt.where(Document.doc_type == doc_type)

    results: list[RetrievedChunk] = []
    for chunk, document, distance in db.execute(stmt).all():
        similarity = 1.0 - float(distance)
        if similarity < min_similarity:
            continue
        results.append(
            RetrievedChunk(
                source=document.source,
                document_id=str(document.id),
                chunk_id=str(chunk.id),
                content=chunk.content,
                similarity_score=round(similarity, 4),
                metadata={**(chunk.chunk_metadata or {}), "title": document.title, "doc_type": document.doc_type},
            )
        )
    return results


def retrieve_semantic_memories(
    db: Session,
    user_id: uuid.UUID,
    query: str,
    *,
    top_k: int = 5,
) -> list[RetrievedChunk]:
    """Same idea as retrieve_documents, but over the semantic_memories table (section 16)."""
    try:
        query_embedding = embed_text(query)
    except EmbeddingUnavailableError as exc:
        raise RetrievalError(f"Could not embed query for memory retrieval: {exc}") from exc

    stmt = (
        select(SemanticMemory, SemanticMemory.embedding.cosine_distance(query_embedding).label("distance"))
        .where(SemanticMemory.user_id == user_id)
        .order_by("distance")
        .limit(top_k)
    )

    results: list[RetrievedChunk] = []
    for mem, distance in db.execute(stmt).all():
        results.append(
            RetrievedChunk(
                source="semantic_memory",
                document_id=str(mem.id),
                chunk_id=str(mem.id),
                content=mem.text,
                similarity_score=round(1.0 - float(distance), 4),
                metadata={"created_at": mem.created_at.isoformat()},
            )
        )
    return results
