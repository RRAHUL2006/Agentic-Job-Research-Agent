"""
app/db/init_db.py
------------------
WHAT: Enables the pgvector extension and creates every table declared in
      app/db/models.py. Also seeds one demo user so the rest of the system
      has something to attach sessions/memories to out of the box.
WHY:  A single, explicit entrypoint instead of "run some ORM magic on
      import" — you can see exactly what happens and when.
IN:   A running, reachable Postgres instance (see docker-compose.yml).
OUT:  Tables created; prints a summary; idempotent (safe to re-run).

Run with:  python -m app.db.init_db
"""
from __future__ import annotations

import sys

from sqlalchemy import text

from app.db.models import Base, User
from app.db.session import engine, session_scope

DEMO_USER_EMAIL = "demo@example.com"


def enable_pgvector() -> None:
    with engine.begin() as conn:
        conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))


def create_tables() -> None:
    Base.metadata.create_all(bind=engine)


def seed_demo_user() -> None:
    with session_scope() as db:
        existing = db.query(User).filter_by(email=DEMO_USER_EMAIL).first()
        if not existing:
            db.add(User(email=DEMO_USER_EMAIL, display_name="Demo User"))


def main() -> None:
    try:
        enable_pgvector()
        create_tables()
        seed_demo_user()
    except Exception as exc:  # noqa: BLE001 - top-level CLI entrypoint
        print(f"[init_db] FAILED: {exc}", file=sys.stderr)
        print(
            "[init_db] Is Postgres running? Try: docker compose up -d postgres",
            file=sys.stderr,
        )
        sys.exit(1)

    print("[init_db] pgvector extension enabled.")
    print("[init_db] Tables created (or already existed):")
    for table_name in Base.metadata.tables:
        print(f"           - {table_name}")
    print(f"[init_db] Demo user ready: {DEMO_USER_EMAIL}")


if __name__ == "__main__":
    main()
