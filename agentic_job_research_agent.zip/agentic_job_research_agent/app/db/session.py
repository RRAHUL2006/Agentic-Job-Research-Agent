"""
app/db/session.py
------------------
WHAT: Creates the SQLAlchemy engine and a session factory for PostgreSQL.
WHY:  Every other module that touches the database imports `SessionLocal`
      from here instead of building its own connection — one source of
      truth for how we talk to Postgres.
IN:   settings.database_url (see app/config.py).
OUT:  `engine`, `SessionLocal`, and a `get_db()` generator for FastAPI's
      dependency-injection system.
"""
from __future__ import annotations

from contextlib import contextmanager
from typing import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from app.config import settings

# pool_pre_ping avoids handing out dead connections after Postgres restarts —
# a common source of confusing errors in long-running dev sessions.
engine = create_engine(settings.database_url, pool_pre_ping=True, future=True)

SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


def get_db() -> Generator[Session, None, None]:
    """FastAPI dependency: `db: Session = Depends(get_db)`."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@contextmanager
def session_scope() -> Generator[Session, None, None]:
    """
    Context manager for use OUTSIDE FastAPI (LangGraph nodes, scripts, tests).

        with session_scope() as db:
            db.add(obj)
    Commits on success, rolls back on exception, always closes.
    """
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
