"""
app/config.py
--------------
WHAT: A single place that reads every configuration value from environment
      variables (with sane defaults) so nothing is hard-coded elsewhere.
WHY:  Twelve-factor apps keep config outside code. It also means a student
      can point this project at a different Ollama model or a different
      Postgres instance without touching a single line of Python.
IN:   Environment variables (loaded from a `.env` file in local dev).
OUT:  A `settings` object imported everywhere else in the app.
"""
from __future__ import annotations

import os
from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # --- LLM (Ollama) -----------------------------------------------------
    ollama_base_url: str = Field(default="http://localhost:11434")
    ollama_model: str = Field(default="llama3.1:8b")
    ollama_temperature: float = Field(default=0.2)
    ollama_request_timeout: float = Field(default=120.0)

    # --- Embeddings ---------------------------------------------------------
    embedding_model: str = Field(default="nomic-embed-text")
    embedding_dim: int = Field(default=768)  # nomic-embed-text output size

    # --- PostgreSQL ---------------------------------------------------------
    postgres_host: str = Field(default="localhost")
    postgres_port: int = Field(default=5432)
    postgres_db: str = Field(default="agentic_jobs")
    postgres_user: str = Field(default="postgres")
    postgres_password: str = Field(default="postgres")

    @property
    def database_url(self) -> str:
        return (
            f"postgresql+psycopg://{self.postgres_user}:{self.postgres_password}"
            f"@{self.postgres_host}:{self.postgres_port}/{self.postgres_db}"
        )

    # --- Agent / Graph behaviour --------------------------------------------
    max_agent_steps: int = Field(default=8)          # hard stop against infinite loops
    max_reflection_retries: int = Field(default=2)    # how many times reflection may send us back
    top_k_retrieval: int = Field(default=5)

    # --- API -----------------------------------------------------------------
    api_host: str = Field(default="0.0.0.0")
    api_port: int = Field(default=8000)

    # --- Web search provider --------------------------------------------------
    web_search_provider: str = Field(default="mock")  # "mock" or "real"
    web_search_api_key: str | None = Field(default=None)


@lru_cache
def get_settings() -> Settings:
    """Cached so we parse the environment exactly once per process."""
    return Settings()


settings = get_settings()
