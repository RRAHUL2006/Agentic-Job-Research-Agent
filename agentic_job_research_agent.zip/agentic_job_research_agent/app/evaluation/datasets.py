"""
app/evaluation/datasets.py
------------------------------
WHAT: The fixed set of evaluation tasks (section 24 requires at least 10).
WHY:  A stable, versioned dataset means evaluation runs are comparable
      over time — "did my prompt change make things better or worse?"
      only means something if the questions don't also change.

Each task has:
  name                 - unique identifier
  user_request          - what gets sent to run_agent()
  expects_tool          - a tool name we expect to see used (for tool-
                           selection-accuracy scoring), or None
  expects_keywords      - lowercase substrings the final answer should
                           contain for a naive groundedness/success check
  simulate_failure       - if True, the task is scored for graceful
                           degradation rather than a normal answer
"""
from __future__ import annotations

from typing import TypedDict


class EvalTask(TypedDict):
    name: str
    user_request: str
    expects_tool: str | None
    expects_keywords: list[str]
    simulate_failure: bool


EVAL_TASKS: list[EvalTask] = [
    {
        "name": "find_data_engineer_jobs",
        "user_request": "Find Data Engineer jobs matching my skills.",
        "expects_tool": "search_jobs",
        "expects_keywords": ["data engineer"],
        "simulate_failure": False,
    },
    {
        "name": "research_bp",
        "user_request": "Research BP and find relevant Data/AI roles.",
        "expects_tool": "get_company_info",
        "expects_keywords": ["bp"],
        "simulate_failure": False,
    },
    {
        "name": "compare_job_with_profile",
        "user_request": "Compare this job with my profile: requires Python, SQL, Airflow.",
        "expects_tool": "calculate_match_score",
        "expects_keywords": ["match"],
        "simulate_failure": False,
    },
    {
        "name": "identify_skill_gaps",
        "user_request": "What skills am I missing for a Data Engineering role?",
        "expects_tool": "calculate_match_score",
        "expects_keywords": ["skill"],
        "simulate_failure": False,
    },
    {
        "name": "save_preference",
        "user_request": "Remember that I prefer Data Engineering roles.",
        "expects_tool": "remember",
        "expects_keywords": [],
        "simulate_failure": False,
    },
    {
        "name": "retrieve_preference",
        "user_request": "What role did I say I prefer?",
        "expects_tool": "recall",
        "expects_keywords": [],
        "simulate_failure": False,
    },
    {
        "name": "create_learning_plan",
        "user_request": "Create a learning plan for my skill gaps in Spark and Airflow.",
        "expects_tool": "create_learning_plan",
        "expects_keywords": ["plan"],
        "simulate_failure": False,
    },
    {
        "name": "research_bp_interview_prep",
        "user_request": "Research BP and tell me what I should prepare for a Data Engineer interview.",
        "expects_tool": "get_company_info",
        "expects_keywords": ["bp"],
        "simulate_failure": False,
    },
    {
        "name": "compare_multiple_jobs",
        "user_request": "Compare several jobs and identify their common requirements.",
        "expects_tool": "rank_jobs",
        "expects_keywords": [],
        "simulate_failure": False,
    },
    {
        "name": "handle_unknown_company",
        "user_request": "Research a company called Zzyzx Nonexistent Corp and find AI roles there.",
        "expects_tool": "get_company_info",
        "expects_keywords": [],
        "simulate_failure": False,
    },
    {
        "name": "simulate_tool_failure",
        "user_request": "Rank these jobs: this is deliberately malformed JSON to trigger an error.",
        "expects_tool": "rank_jobs",
        "expects_keywords": [],
        "simulate_failure": True,
    },
]
