"""
app/evaluation/metrics.py
------------------------------
WHAT: Pure scoring functions used by the evaluator. Kept separate from
      evaluator.py's orchestration so each metric is independently
      testable (see tests/test_evaluation.py).
WHY:  Section 24 lists ten dimensions to measure. We compute the ones that
      are cheaply and objectively measurable from a single agent run:
      task success, tool-selection accuracy, groundedness (naive keyword
      check), latency, step count, and failure recovery. Retrieval
      quality and memory accuracy are measured the same way via their own
      dedicated eval tasks in datasets.py rather than a separate formula.
"""
from __future__ import annotations


def tool_selection_correct(expects_tool: str | None, tool_results: list[dict]) -> bool | None:
    if expects_tool is None:
        return None
    used = {r["tool_name"] for r in tool_results}
    return expects_tool in used


def keyword_success(answer: str | None, expected_keywords: list[str]) -> bool:
    if not expected_keywords:
        return bool(answer)
    if not answer:
        return False
    lowered = answer.lower()
    return all(kw in lowered for kw in expected_keywords)


def groundedness_score(answer: str | None, retrieved_context: list[dict]) -> float | None:
    """
    Naive groundedness proxy: fraction of retrieved-evidence source labels
    that also appear referenced in the final answer's neighborhood text.
    A real system would use an LLM-as-judge; this keeps the eval loop fast
    and dependency-free while still surfacing a meaningful signal (0 for
    "answer ignored all evidence" up to 1 for "referenced everything").
    """
    if not retrieved_context:
        return None
    if not answer:
        return 0.0
    lowered = answer.lower()
    hits = sum(1 for c in retrieved_context if c["content"][:30].lower() in lowered)
    return round(hits / len(retrieved_context), 3)


def recovered_gracefully(simulate_failure: bool, errors: list[str], answer: str | None) -> bool | None:
    if not simulate_failure:
        return None
    # "Graceful" means: an error was recorded AND we still produced some answer
    # (i.e. the graph didn't crash and finalizer_node's fallback text kicked in).
    return bool(errors) and bool(answer)
