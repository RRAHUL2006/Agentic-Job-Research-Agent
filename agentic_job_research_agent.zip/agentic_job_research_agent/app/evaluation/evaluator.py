"""
app/evaluation/evaluator.py
-------------------------------
WHAT: `run_evaluation_suite()` — runs every task in datasets.py (or one
      named task) through the real agent, scores it with metrics.py, and
      persists results to the `evaluations` table.
WHY:  This is what /evaluate (FastAPI) and the Streamlit "Evaluation" tab
      call. It's a genuine end-to-end run (not mocked) — every evaluation
      exercises the full planner -> retriever -> agent -> tools ->
      reflection -> finalizer graph, so a regression anywhere shows up
      here.
"""
from __future__ import annotations

import time

from app.agent.runtime import run_agent
from app.db.models import Evaluation
from app.db.session import session_scope
from app.evaluation.datasets import EVAL_TASKS, EvalTask
from app.evaluation.metrics import (
    groundedness_score,
    keyword_success,
    recovered_gracefully,
    tool_selection_correct,
)


def _run_single_task(task: EvalTask) -> dict:
    start = time.perf_counter()
    try:
        result = run_agent(task["user_request"])
        crashed = False
    except Exception as exc:  # noqa: BLE001 - the eval harness must survive a crashed run
        result = {"answer": None, "tool_results": [], "errors": [str(exc)], "step_count": 0, "retrieved_context": []}
        crashed = True
    latency_ms = int((time.perf_counter() - start) * 1000)

    if task["simulate_failure"]:
        success = recovered_gracefully(True, result["errors"], result["answer"])
    else:
        success = (not crashed) and keyword_success(result["answer"], task["expects_keywords"])

    score = {
        "task_name": task["name"],
        "success": bool(success),
        "tool_selection_correct": tool_selection_correct(task["expects_tool"], result["tool_results"]),
        "groundedness_score": groundedness_score(result["answer"], result["retrieved_context"]),
        "latency_ms": latency_ms,
        "step_count": result.get("step_count", 0),
        "notes": "; ".join(result.get("errors", [])) or None,
    }

    with session_scope() as db:
        db.add(Evaluation(**score))

    return score


def run_evaluation_suite(task_name: str | None = None) -> dict:
    tasks = [t for t in EVAL_TASKS if t["name"] == task_name] if task_name else EVAL_TASKS
    if task_name and not tasks:
        return {"error": f"Unknown task_name: {task_name!r}"}

    results = [_run_single_task(t) for t in tasks]

    success_count = sum(1 for r in results if r["success"])
    total = len(results)
    avg_latency = round(sum(r["latency_ms"] for r in results) / total, 1) if total else 0
    avg_steps = round(sum(r["step_count"] for r in results) / total, 2) if total else 0

    return {
        "task_count": total,
        "success_rate": round(success_count / total, 3) if total else 0,
        "average_latency_ms": avg_latency,
        "average_steps": avg_steps,
        "results": results,
    }
