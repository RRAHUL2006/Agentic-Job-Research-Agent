"""
app/ui/streamlit_app.py
---------------------------
WHAT: The Streamlit dashboard (section 26): Chat, Agent Graph, Tools,
      Memory, RAG, Evaluation, System tabs.
WHY:  Gives a visual, no-code way to see the agent's internals — the whole
      point of an educational project like this is watching the
      planner -> retriever -> agent -> tools -> reflection -> finalizer
      loop actually happen, not just seeing a final chat bubble.
IN:   User interaction (chat input, buttons).
OUT:  Renders in the browser. Talks directly to the agent runtime and DB
      (no need to go through the FastAPI layer for a single-process
      local demo, though API_BASE_URL is honored if set for a
      containerized deployment).

Run with:  streamlit run app/ui/streamlit_app.py
"""
from __future__ import annotations

import os
import uuid

import streamlit as st
from sqlalchemy import text

from app.agent.llm import LLMUnavailableError, get_llm, invoke_with_recovery
from app.agent.runtime import run_agent
from app.config import settings
from app.db.models import AgentTrace, Evaluation, Memory
from app.db.session import session_scope
from app.evaluation.evaluator import run_evaluation_suite
from app.retrieval.retriever import RetrievalError, retrieve_documents

st.set_page_config(page_title="Agentic Job Research Agent", layout="wide")
st.title("🧭 Agentic Job Research Agent")
st.caption("LangGraph + Ollama + PostgreSQL/pgvector — a teaching-grade agentic AI system.")

if "session_id" not in st.session_state:
    st.session_state.session_id = None
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "last_result" not in st.session_state:
    st.session_state.last_result = None

tabs = st.tabs(["💬 Chat", "🕸️ Agent Graph", "🔧 Tools", "🧠 Memory", "📚 RAG", "📊 Evaluation", "🖥️ System"])

# ---------------------------------------------------------------------------
# Chat
# ---------------------------------------------------------------------------
with tabs[0]:
    for role, content in st.session_state.chat_history:
        with st.chat_message(role):
            st.write(content)

    user_input = st.chat_input("Ask about jobs, companies, skill gaps, learning plans...")
    if user_input:
        st.session_state.chat_history.append(("user", user_input))
        with st.chat_message("user"):
            st.write(user_input)
        with st.chat_message("assistant"):
            with st.spinner("Planning → retrieving → reasoning → (tools?) → reflecting..."):
                result = run_agent(user_input, session_id=st.session_state.session_id)
            st.session_state.session_id = result["session_id"]
            st.session_state.last_result = result
            st.write(result["answer"])
            if result["errors"]:
                st.warning("Encountered issues: " + "; ".join(result["errors"]))
        st.session_state.chat_history.append(("assistant", result["answer"]))

# ---------------------------------------------------------------------------
# Agent Graph
# ---------------------------------------------------------------------------
with tabs[1]:
    st.subheader("Execution path for the last request")
    result = st.session_state.last_result
    if not result:
        st.info("Ask something in the Chat tab first.")
    else:
        st.write("**Plan:**")
        for task in result["plan"]:
            st.markdown(f"- `{task['status']}` {task['description']}")

        st.write("**Node trail (concise action summaries only — no chain-of-thought):**")
        for event in result["events"]:
            st.markdown(f"**{event['node']}** — {event['event_type']}: {event['summary']}")

# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------
with tabs[2]:
    st.subheader("Tool calls for the last request")
    result = st.session_state.last_result
    if not result or not result["tool_results"]:
        st.info("No tool calls yet — ask something that requires a lookup or calculation.")
    else:
        for tr in result["tool_results"]:
            with st.expander(f"{tr['tool_name']} — {tr['status']}"):
                st.write("**Arguments**")
                st.json(tr["arguments"])
                st.write("**Result**")
                st.json(tr["result"])

# ---------------------------------------------------------------------------
# Memory
# ---------------------------------------------------------------------------
with tabs[3]:
    st.subheader("Long-term memory")
    with session_scope() as db:
        rows = db.query(Memory).order_by(Memory.updated_at.desc()).limit(50).all()
        memory_rows = [
            {"user_id": str(m.user_id), "key": m.memory_key, "value": m.memory_value, "updated": m.updated_at.isoformat()}
            for m in rows
        ]
    if memory_rows:
        st.dataframe(memory_rows, use_container_width=True)
    else:
        st.info("No memories stored yet. Try: \"Remember that I prefer Data Engineering roles.\"")

# ---------------------------------------------------------------------------
# RAG
# ---------------------------------------------------------------------------
with tabs[4]:
    st.subheader("Retrieval-augmented generation")
    query = st.text_input("Try a retrieval query", value="data engineering skills")
    if st.button("Search documents"):
        with session_scope() as db:
            try:
                chunks = retrieve_documents(db, query, top_k=settings.top_k_retrieval)
            except RetrievalError as exc:
                st.error(str(exc))
                chunks = []
        for c in chunks:
            with st.expander(f"{c.source} — similarity {c.similarity_score}"):
                st.write(c.content)
                st.caption(f"document_id={c.document_id} chunk_id={c.chunk_id}")
        if not chunks:
            st.info("No results. Ingest documents first (see app/retrieval/ingest.py).")

# ---------------------------------------------------------------------------
# Evaluation
# ---------------------------------------------------------------------------
with tabs[5]:
    st.subheader("Evaluation suite")
    if st.button("Run full evaluation suite (calls the real agent, takes a while)"):
        with st.spinner("Running evaluation tasks..."):
            summary = run_evaluation_suite()
        st.metric("Success rate", f"{summary['success_rate'] * 100:.1f}%")
        col1, col2 = st.columns(2)
        col1.metric("Avg latency (ms)", summary["average_latency_ms"])
        col2.metric("Avg steps", summary["average_steps"])
        st.dataframe(summary["results"], use_container_width=True)

    st.write("**Historical evaluation runs**")
    with session_scope() as db:
        rows = db.query(Evaluation).order_by(Evaluation.created_at.desc()).limit(50).all()
        eval_rows = [
            {
                "task": e.task_name,
                "success": e.success,
                "tool_ok": e.tool_selection_correct,
                "groundedness": e.groundedness_score,
                "latency_ms": e.latency_ms,
                "steps": e.step_count,
                "created_at": e.created_at.isoformat(),
            }
            for e in rows
        ]
    if eval_rows:
        st.dataframe(eval_rows, use_container_width=True)
    else:
        st.info("No evaluation runs yet.")

# ---------------------------------------------------------------------------
# System
# ---------------------------------------------------------------------------
with tabs[6]:
    st.subheader("System status")

    col1, col2, col3 = st.columns(3)
    with col1:
        st.write("**Ollama**")
        try:
            invoke_with_recovery(get_llm(), [])
            st.success(f"Reachable ({settings.ollama_model})")
        except LLMUnavailableError as exc:
            st.error(f"Unreachable: {exc}")
        except Exception:
            st.warning("Reachable, but a test call could not be evaluated cleanly.")

    with col2:
        st.write("**PostgreSQL**")
        try:
            with session_scope() as db:
                db.execute(text("SELECT 1"))
            st.success(f"Connected ({settings.postgres_host}:{settings.postgres_port}/{settings.postgres_db})")
        except Exception as exc:  # noqa: BLE001
            st.error(f"Unreachable: {exc}")

    with col3:
        st.write("**pgvector**")
        try:
            with session_scope() as db:
                db.execute(text("SELECT '[1,2,3]'::vector"))
            st.success("Extension enabled")
        except Exception as exc:  # noqa: BLE001
            st.error(f"Not available: {exc}")

    st.divider()
    st.write("**Current session**")
    st.code(st.session_state.session_id or "(none yet — send a chat message)")
