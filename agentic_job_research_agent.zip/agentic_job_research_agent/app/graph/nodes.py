"""
app/graph/nodes.py
---------------------
WHAT: Every node function in the graph:

    START -> planner -> retriever -> agent -> [tools -> agent]* -> reflection -> finalizer -> END

    (reflection can loop back to agent a limited number of times — see
     app/graph/edges.py for the routing logic)

WHY:  Each node is a small, single-purpose function so the whole workflow
      stays teachable: read the function, understand the step. None of
      these hard-code which tools get called — the `agent` node lets the
      LLM decide via tool_calling, per section 1 of the spec ("do not
      hard-code a fixed sequence").
IN:   AgentState (see app/graph/state.py).
OUT:  A partial AgentState update (LangGraph merges it into the running
      state).

Every node appends to `events` — this is the ONLY place chain-of-thought
would leak if we let it, so every summary written here is deliberately a
short, factual, non-reasoning description of *what happened*, never *why*
the model thought what it thought.
"""
from __future__ import annotations

import json
import logging
import time
import uuid

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage

from app.agent.llm import LLMUnavailableError, get_llm, invoke_with_recovery
from app.config import settings
from app.db.models import AgentTrace, Plan, Task, ToolCall
from app.db.session import session_scope
from app.graph.state import AgentState
from app.retrieval.retriever import RetrievalError, retrieve_documents
from app.tools.registry import ALL_TOOLS, TOOLS_BY_NAME

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """\
You are a Job Research Agent. You help the user research companies, find \
relevant jobs, evaluate how well jobs match their profile, identify skill \
gaps, and build learning plans.

Rules:
- Use tools when you need facts (job data, company data, memory, retrieved \
documents, calculations). Do not guess at facts a tool could look up.
- If retrieved evidence is available in the conversation, ground your \
answer in it and say so.
- Never claim a match score predicts hiring success — it only reflects \
skill overlap.
- Be concise and directly address every part of the user's request.
- When you have enough information to fully answer, respond with a final \
answer in plain text and do not call any more tools.
"""


def _log_trace(session_id: str, node: str, event_type: str, **kwargs) -> None:
    """Best-effort write to agent_traces. Never let observability break the graph."""
    try:
        with session_scope() as db:
            db.add(
                AgentTrace(
                    session_id=uuid.UUID(session_id),
                    node=node,
                    event_type=event_type,
                    tool_name=kwargs.get("tool_name"),
                    arguments=kwargs.get("arguments") or {},
                    result_metadata=kwargs.get("result_metadata") or {},
                    duration_ms=kwargs.get("duration_ms"),
                    status=kwargs.get("status", "ok"),
                )
            )
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to write agent trace (non-fatal): %s", exc)


# ---------------------------------------------------------------------------
# 1. Planner
# ---------------------------------------------------------------------------
def planner_node(state: AgentState) -> dict:
    """
    Asks the LLM (no tools bound) to break the request into a short,
    ordered task list. This is *displayed* to the user (section 12) but
    does not itself decide which tools run — the agent node still makes
    that call dynamically, task by task.
    """
    llm = get_llm()
    prompt = [
        SystemMessage(
            content=(
                "Break the user's request into 3-8 short, concrete task "
                "descriptions, one per line, no numbering, no explanations. "
                "Each line should describe a single actionable step."
            )
        ),
        HumanMessage(content=state["user_request"]),
    ]

    try:
        response = invoke_with_recovery(llm, prompt)
        lines = [line.strip("- ").strip() for line in response.content.splitlines() if line.strip()]
    except LLMUnavailableError as exc:
        # Degrade gracefully: proceed with a single generic task rather than failing outright.
        lines = ["Answer the user's request directly."]
        state.setdefault("errors", []).append(f"Planner: LLM unavailable, using fallback plan ({exc})")

    plan = [{"id": str(i + 1), "description": desc, "status": "pending"} for i, desc in enumerate(lines)]

    try:
        with session_scope() as db:
            plan_row = Plan(session_id=uuid.UUID(state["session_id"]), user_request=state["user_request"])
            db.add(plan_row)
            db.flush()
            for i, task in enumerate(plan):
                db.add(Task(plan_id=plan_row.id, description=task["description"], order_index=i))
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to persist plan (non-fatal): %s", exc)

    _log_trace(state["session_id"], "planner", "node_end", result_metadata={"task_count": len(plan)})

    return {
        "plan": plan,
        "current_task": plan[0]["description"] if plan else None,
        "events": [{"node": "planner", "event_type": "node_end", "summary": f"Created {len(plan)}-step plan."}],
    }


# ---------------------------------------------------------------------------
# 2. Retriever
# ---------------------------------------------------------------------------
def retriever_node(state: AgentState) -> dict:
    """
    Runs one RAG pass over the raw user request before the agent loop
    starts, so the agent node begins with whatever relevant context
    already exists (resume, prior company notes, etc.) instead of always
    needing a tool call to discover it.
    """
    try:
        with session_scope() as db:
            chunks = retrieve_documents(db, state["user_request"], top_k=settings.top_k_retrieval)
    except RetrievalError as exc:
        _log_trace(state["session_id"], "retriever", "error", status="error", result_metadata={"error": str(exc)})
        return {
            "retrieved_context": [],
            "errors": [f"Retriever: {exc}"],
            "events": [{"node": "retriever", "event_type": "error", "summary": "Retrieval unavailable, continuing without it."}],
        }

    evidence = [
        {
            "source": c.source,
            "document_id": c.document_id,
            "chunk_id": c.chunk_id,
            "content": c.content,
            "similarity_score": c.similarity_score,
        }
        for c in chunks
    ]
    _log_trace(state["session_id"], "retriever", "node_end", result_metadata={"chunks_found": len(evidence)})
    return {
        "retrieved_context": evidence,
        "events": [{"node": "retriever", "event_type": "node_end", "summary": f"Retrieved {len(evidence)} evidence chunk(s)."}],
    }


# ---------------------------------------------------------------------------
# 3. Agent (the reasoning/tool-selection step)
# ---------------------------------------------------------------------------
def agent_node(state: AgentState) -> dict:
    """
    The core decision point. Receives the full conversation plus retrieved
    evidence and the current plan, and decides whether to call a tool or
    produce a final answer. This is where "the LLM dynamically selects
    tools" (section 1) actually happens — nothing here hard-codes which
    tool runs next.
    """
    messages = state.get("messages", [])
    if not messages:
        evidence_block = _format_evidence(state.get("retrieved_context", []))
        plan_block = _format_plan(state.get("plan", []))
        context_msg = (
            f"User request: {state['user_request']}\n\n"
            f"Plan:\n{plan_block}\n\n"
            f"Retrieved evidence:\n{evidence_block}\n\n"
            f"user_id (pass this to memory tools): {state['user_id']}"
        )
        messages = [SystemMessage(content=SYSTEM_PROMPT), HumanMessage(content=context_msg)]

    llm = get_llm(tools=ALL_TOOLS)

    try:
        ai_message: AIMessage = invoke_with_recovery(llm, messages)
    except LLMUnavailableError as exc:
        error_msg = AIMessage(content=f"I couldn't reach the language model to continue: {exc}")
        return {
            "messages": [error_msg] if not state.get("messages") else [error_msg],
            "errors": [f"Agent: {exc}"],
            "final_answer": (
                "I'm unable to reach the local LLM right now, so I can't complete this "
                "request. Please make sure Ollama is running and try again."
            ),
            "events": [{"node": "agent", "event_type": "error", "summary": "LLM unavailable."}],
        }

    step_count = state.get("step_count", 0) + 1
    new_messages = [] if state.get("messages") else [SystemMessage(content=SYSTEM_PROMPT), messages[-1]]
    new_messages.append(ai_message)

    has_tool_calls = bool(getattr(ai_message, "tool_calls", None))
    summary = (
        f"Requested {len(ai_message.tool_calls)} tool call(s)."
        if has_tool_calls
        else "Produced a candidate answer."
    )
    _log_trace(state["session_id"], "agent", "decision", result_metadata={"has_tool_calls": has_tool_calls})

    update: dict = {
        "messages": new_messages,
        "step_count": step_count,
        "events": [{"node": "agent", "event_type": "decision", "summary": summary}],
    }
    if not has_tool_calls:
        update["final_answer"] = ai_message.content
    return update


def _format_evidence(evidence: list[dict]) -> str:
    if not evidence:
        return "(none retrieved)"
    return "\n".join(
        f"- [{e['source']} | similarity={e['similarity_score']}] {e['content'][:300]}" for e in evidence
    )


def _format_plan(plan: list[dict]) -> str:
    if not plan:
        return "(no plan)"
    return "\n".join(f"{t['id']}. {t['description']}" for t in plan)


# ---------------------------------------------------------------------------
# 4. Tools (custom ToolNode with tracing + error containment)
# ---------------------------------------------------------------------------
def tool_node(state: AgentState) -> dict:
    """
    Executes every tool call requested by the last AIMessage. Uses the
    registry whitelist (app/tools/registry.py) — a tool name that isn't
    registered is refused rather than silently ignored (section 14).
    """
    last_message = state["messages"][-1]
    tool_calls = getattr(last_message, "tool_calls", []) or []

    tool_messages = []
    results: list[dict] = []

    for call in tool_calls:
        name, args, call_id = call["name"], call.get("args", {}), call["id"]
        start = time.perf_counter()

        if name not in TOOLS_BY_NAME:
            output = {"error": f"Tool '{name}' is not registered. Refusing to execute."}
            status = "error"
        else:
            try:
                output = TOOLS_BY_NAME[name].invoke(args)
                status = "error" if isinstance(output, dict) and output.get("error") else "success"
            except Exception as exc:  # noqa: BLE001 - tool boundary
                output = {"error": f"Unhandled tool exception: {exc}"}
                status = "error"

        duration_ms = int((time.perf_counter() - start) * 1000)
        results.append({"tool_name": name, "arguments": args, "result": output, "status": status})

        try:
            with session_scope() as db:
                db.add(
                    ToolCall(
                        session_id=uuid.UUID(state["session_id"]),
                        tool_name=name,
                        arguments=args,
                        result_summary=json.dumps(output)[:2000],
                        status=status,
                        duration_ms=duration_ms,
                    )
                )
        except Exception as exc:  # noqa: BLE001
            logger.warning("Failed to persist tool_call (non-fatal): %s", exc)

        _log_trace(
            state["session_id"], "tools", "tool_call",
            tool_name=name, arguments=args, status=status, duration_ms=duration_ms,
        )

        tool_messages.append(ToolMessage(content=json.dumps(output), tool_call_id=call_id))

    errors = [f"Tool {r['tool_name']}: {r['result'].get('error')}" for r in results if r["status"] == "error"]

    return {
        "messages": tool_messages,
        "tool_results": results,
        "errors": errors,
        "events": [
            {"node": "tools", "event_type": "tool_call", "summary": f"Ran {r['tool_name']} -> {r['status']}."}
            for r in results
        ],
    }


# ---------------------------------------------------------------------------
# 5. Reflection
# ---------------------------------------------------------------------------
def reflection_node(state: AgentState) -> dict:
    """
    Validates the candidate final answer against the original request and
    the evidence gathered. Does NOT expose its reasoning — only a pass/fail
    verdict plus, on failure, a short instruction fed back to the agent.
    Retries are capped by settings.max_reflection_retries (section 20).
    """
    llm = get_llm()
    evidence_block = _format_evidence(state.get("retrieved_context", []))
    verdict_prompt = [
        SystemMessage(
            content=(
                "You are validating an AI assistant's draft answer. Reply with "
                "exactly one line starting with PASS or FAIL. If FAIL, follow it "
                "with a short, specific instruction (one sentence) on what's "
                "missing or unsupported. Do not explain your reasoning further."
            )
        ),
        HumanMessage(
            content=(
                f"User request: {state['user_request']}\n\n"
                f"Available evidence:\n{evidence_block}\n\n"
                f"Draft answer:\n{state.get('final_answer', '')}"
            )
        ),
    ]

    retries = state.get("reflection_retries", 0)

    try:
        verdict = invoke_with_recovery(llm, verdict_prompt).content.strip()
    except LLMUnavailableError:
        # If reflection itself can't run, don't block the user on it — pass through.
        return {
            "reflection_passed": True,
            "events": [{"node": "reflection", "event_type": "node_end", "summary": "Reflection skipped (LLM unavailable)."}],
        }

    passed = verdict.upper().startswith("PASS")
    can_retry = retries < settings.max_reflection_retries

    _log_trace(state["session_id"], "reflection", "decision", result_metadata={"passed": passed, "retries": retries})

    if passed or not can_retry:
        return {
            "reflection_passed": True,
            "events": [{"node": "reflection", "event_type": "node_end", "summary": "PASS" if passed else "FAIL (retry limit reached, proceeding)."}],
        }

    # FAIL and we still have retry budget: feed the instruction back to the agent.
    instruction = verdict.split("\n", 1)[-1] if "\n" in verdict else verdict.replace("FAIL", "").strip(": ")
    return {
        "reflection_passed": False,
        "reflection_retries": retries + 1,
        "final_answer": None,
        "messages": [HumanMessage(content=f"Reviewer feedback: {instruction}. Please address this and try again.")],
        "events": [{"node": "reflection", "event_type": "node_end", "summary": f"FAIL — retry {retries + 1}/{settings.max_reflection_retries}."}],
    }


# ---------------------------------------------------------------------------
# 6. Finalizer
# ---------------------------------------------------------------------------
def finalizer_node(state: AgentState) -> dict:
    """
    Last stop before END. Ensures final_answer is always populated (even
    on total failure, per section 22: "report the limitation" rather than
    silently returning nothing) and logs the terminal trace event.
    """
    answer = state.get("final_answer")
    if not answer:
        errors = state.get("errors", [])
        answer = (
            "I wasn't able to fully complete this request."
            + (f" Issues encountered: {'; '.join(errors)}." if errors else "")
        )

    _log_trace(state["session_id"], "finalizer", "node_end", result_metadata={"had_errors": bool(state.get("errors"))})

    return {
        "final_answer": answer,
        "events": [{"node": "finalizer", "event_type": "node_end", "summary": "Final answer ready."}],
    }
