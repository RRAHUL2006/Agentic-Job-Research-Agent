"""
app/graph/state.py
---------------------
WHAT: The single typed dictionary that flows through every node of the
      LangGraph. This IS the agent's working memory for one request.
WHY:  LangGraph nodes are just functions `(state) -> partial_state_update`.
      A precise TypedDict makes every node's contract explicit: what it
      can read, what it's allowed to write. `messages` uses LangGraph's
      `add_messages` reducer so nodes can just return new messages and
      have them appended, instead of manually managing a growing list.
IN:   Nothing (this is a schema, not a function).
OUT:  `AgentState` — imported by every node, the graph builder, and the
      API layer (to construct the initial state for a request).

Per section 11: only concise action summaries, tool calls/outputs, errors,
retrieved evidence, and the final answer are stored. No hidden
chain-of-thought is ever written into this state.
"""
from __future__ import annotations

from typing import Annotated, Any, Literal, TypedDict

from langgraph.graph.message import add_messages

TaskStatus = Literal["pending", "running", "completed", "failed", "skipped"]


class PlanTask(TypedDict):
    id: str
    description: str
    status: TaskStatus


class ToolResult(TypedDict):
    tool_name: str
    arguments: dict
    result: Any
    status: Literal["success", "error"]


class RetrievedEvidence(TypedDict):
    source: str
    document_id: str
    chunk_id: str
    content: str
    similarity_score: float


class AgentEvent(TypedDict):
    """One row of the observability trail shown in the Streamlit 'Agent Graph' tab."""

    node: str
    event_type: str
    summary: str


class AgentState(TypedDict, total=False):
    # --- Identity / request -------------------------------------------------
    session_id: str
    user_id: str
    user_request: str

    # --- Conversation --------------------------------------------------------
    messages: Annotated[list, add_messages]

    # --- Planning --------------------------------------------------------------
    plan: list[PlanTask]
    current_task: str | None

    # --- Evidence & tool activity -----------------------------------------------
    retrieved_context: list[RetrievedEvidence]
    tool_results: list[ToolResult]

    # --- Control flow / bookkeeping -----------------------------------------------
    errors: list[str]
    events: list[AgentEvent]
    step_count: int
    reflection_retries: int
    reflection_passed: bool | None

    # --- Output ------------------------------------------------------------------
    final_answer: str | None
    approval_required: bool
