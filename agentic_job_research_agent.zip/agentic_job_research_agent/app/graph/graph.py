"""
app/graph/graph.py
---------------------
WHAT: Wires the nodes (app/graph/nodes.py) and edges (app/graph/edges.py)
      together into a compiled LangGraph StateGraph:

              START
                |
             planner
                |
             retriever
                |
              agent <---------------+
              /   \\                 |
      (tool call) (no tool call)    |
             |         |            |
           tools    reflection      |
             |       /     \\       |
             +----->/     FAIL,retry|
                    |       (loops back to agent)
                   PASS or
                out of retries
                    |
                finalizer
                    |
                   END

WHY:  This is the one place that shows the whole control flow — everything
      else in app/graph/ is a building block used here.
IN:   Nothing at import time.
OUT:  `build_graph()` -> a compiled, runnable LangGraph app.
"""
from __future__ import annotations

from langgraph.graph import END, START, StateGraph

from app.graph.edges import route_after_agent, route_after_reflection
from app.graph.nodes import (
    agent_node,
    finalizer_node,
    planner_node,
    reflection_node,
    retriever_node,
    tool_node,
)
from app.graph.state import AgentState


def build_graph():
    graph = StateGraph(AgentState)

    graph.add_node("planner", planner_node)
    graph.add_node("retriever", retriever_node)
    graph.add_node("agent", agent_node)
    graph.add_node("tools", tool_node)
    graph.add_node("reflection", reflection_node)
    graph.add_node("finalizer", finalizer_node)

    graph.add_edge(START, "planner")
    graph.add_edge("planner", "retriever")
    graph.add_edge("retriever", "agent")

    graph.add_conditional_edges("agent", route_after_agent, {"tools": "tools", "reflection": "reflection"})
    graph.add_edge("tools", "agent")  # the iterative tool-use loop

    graph.add_conditional_edges(
        "reflection", route_after_reflection, {"agent": "agent", "finalizer": "finalizer"}
    )
    graph.add_edge("finalizer", END)

    return graph.compile()


# Built once per process; LangGraph compiled graphs are stateless/reusable
# across requests (per-request data lives in the AgentState passed to .invoke()).
compiled_graph = build_graph()
