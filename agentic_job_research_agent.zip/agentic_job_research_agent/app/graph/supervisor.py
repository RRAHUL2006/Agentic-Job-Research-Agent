"""
app/graph/supervisor.py
---------------------------
OPTIONAL EXTENSION (spec section 31) — do not wire this into the main
application until the single-agent graph (app/graph/graph.py) is stable
and you've read app/graph/nodes.py end to end. This module is intentionally
kept separate so the core learning path isn't complicated by it.

WHAT: A supervisor architecture that routes a request to one of four
      specialist sub-agents, each a thin LLM call constrained to a subset
      of the tool registry:

                     SUPERVISOR
                         |
        ┌────────────────┼────────────────┐
        ↓                ↓                ↓
   Research Agent    Job Agent       Skill Agent
   (company/web)   (job discovery)  (skill-gap analysis)
        └────────────────┼────────────────┘
                          ↓
                   Learning Agent
                  (learning-plan generation)
                          ↓
                    Final Agent
                 (compiles the reply)

WHY:  This demonstrates the next architectural step beyond a single
      ReAct-style loop: decomposing a broad request ("research BP and
      tell me what to prepare") across specialists with narrower tool
      access, then having one final pass compose the answer. It reuses
      the exact same tool registry and LLM factory as the single-agent
      system — only the routing/composition is different.

HOW TO ACTIVATE:
  1. Import `build_supervisor_graph` where you currently import
     `compiled_graph` from app/graph/graph.py (e.g. in
     app/agent/runtime.py) and call `.invoke()` on it the same way — the
     input/output shape matches app/graph/state.py's AgentState.
  2. Everything else (FastAPI, Streamlit, tracing) keeps working unchanged
     because run_agent() is the only place that touches the compiled graph.
"""
from __future__ import annotations

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, START, StateGraph

from app.agent.llm import get_llm
from app.graph.state import AgentState
from app.tools.analysis_tools import calculate_match_score, create_learning_plan
from app.tools.company_tools import get_company_info
from app.tools.job_tools import extract_job_requirements, rank_jobs, search_jobs
from app.tools.retrieval_tools import retrieve_documents_tool

RESEARCH_TOOLS = [get_company_info, retrieve_documents_tool]
JOB_TOOLS = [search_jobs, extract_job_requirements]
SKILL_TOOLS = [calculate_match_score, rank_jobs]
LEARNING_TOOLS = [create_learning_plan]


def _sub_agent(role_prompt: str, tools: list) -> callable:
    """Factory: builds a minimal single-turn tool-calling node for one specialist."""

    def node(state: AgentState) -> dict:
        llm = get_llm(tools=tools)
        response = llm.invoke(
            [
                SystemMessage(content=role_prompt),
                HumanMessage(content=state["user_request"]),
            ]
        )
        summary = getattr(response, "content", "") or "(tool call requested)"
        return {
            "events": [{"node": role_prompt[:20], "event_type": "sub_agent", "summary": summary[:200]}],
            "tool_results": state.get("tool_results", []),
        }

    return node


research_agent_node = _sub_agent(
    "You are the Research Agent. Investigate the company mentioned in the request using get_company_info "
    "and retrieve_documents_tool. Report findings concisely.",
    RESEARCH_TOOLS,
)
job_agent_node = _sub_agent(
    "You are the Job Agent. Find and structure relevant jobs using search_jobs and "
    "extract_job_requirements. Report findings concisely.",
    JOB_TOOLS,
)
skill_agent_node = _sub_agent(
    "You are the Skill Agent. Compare the user's skills against job requirements using "
    "calculate_match_score and rank_jobs. Report findings concisely.",
    SKILL_TOOLS,
)
learning_agent_node = _sub_agent(
    "You are the Learning Agent. Turn identified skill gaps into a prioritized plan using "
    "create_learning_plan. Report the plan concisely.",
    LEARNING_TOOLS,
)


def final_agent_node(state: AgentState) -> dict:
    """Composes the specialists' summaries (from `events`) into one final answer."""
    summaries = [e["summary"] for e in state.get("events", []) if e.get("event_type") == "sub_agent"]
    llm = get_llm()
    response = llm.invoke(
        [
            SystemMessage(content="Combine these specialist findings into one clear, concise answer for the user."),
            HumanMessage(content="\n\n".join(summaries) or "No specialist findings were produced."),
        ]
    )
    return {"final_answer": response.content}


def build_supervisor_graph():
    """
    Simple fixed fan-out/fan-in for clarity (research + job + skill run in
    sequence here; making them run concurrently is a natural next exercise
    using LangGraph's parallel-branch support once you're comfortable with
    the sequential version).
    """
    graph = StateGraph(AgentState)
    graph.add_node("research_agent", research_agent_node)
    graph.add_node("job_agent", job_agent_node)
    graph.add_node("skill_agent", skill_agent_node)
    graph.add_node("learning_agent", learning_agent_node)
    graph.add_node("final_agent", final_agent_node)

    graph.add_edge(START, "research_agent")
    graph.add_edge("research_agent", "job_agent")
    graph.add_edge("job_agent", "skill_agent")
    graph.add_edge("skill_agent", "learning_agent")
    graph.add_edge("learning_agent", "final_agent")
    graph.add_edge("final_agent", END)

    return graph.compile()
