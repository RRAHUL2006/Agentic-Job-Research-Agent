"""
app/graph/edges.py
---------------------
WHAT: The conditional-routing functions that make this an actual graph
      (with branches and loops) instead of a straight line.
WHY:  Section 10 requires:
          agent -> tool call exists? -> tools : reflection
          tools -> agent                          (the iterative loop)
          reflection -> FAIL & retries left? -> agent : finalizer
      Each function below returns a STRING naming the next node; LangGraph
      uses that string to look up the edge via `add_conditional_edges`.
IN:   AgentState.
OUT:  str — the name of the next node.
"""
from __future__ import annotations

from app.config import settings
from app.graph.state import AgentState


def route_after_agent(state: AgentState) -> str:
    """After the agent node: did it request a tool call, or is it done?"""
    if state.get("step_count", 0) >= settings.max_agent_steps:
        # Section 22: maximum step exhaustion -> stop looping, go finalize
        # with whatever we have rather than looping forever.
        return "reflection"

    last_message = state["messages"][-1] if state.get("messages") else None
    has_tool_calls = bool(getattr(last_message, "tool_calls", None))
    return "tools" if has_tool_calls else "reflection"


def route_after_reflection(state: AgentState) -> str:
    """After reflection: retry the agent, or finalize?"""
    if state.get("reflection_passed", True):
        return "finalizer"
    return "agent"
