"""
app/tools/job_tools.py
--------------------------
WHAT: `search_jobs`, `extract_job_requirements`, `rank_jobs`.
WHY:  These cover job discovery (search Postgres first, fall back to the
      web provider) and the two transformation steps the spec calls for:
      turning a free-text job description into structured requirements,
      and comparing several jobs against each other.
"""
from __future__ import annotations

import json
import re

from langchain_core.tools import tool
from sqlalchemy import or_

from app.db.models import Job
from app.db.session import session_scope
from app.tools.base import safe_tool_call
from app.tools.web_tools import get_web_search_provider

# A small, extensible skill vocabulary used for naive keyword extraction
# when structured requirements aren't already present. Real projects would
# use an LLM call here (see extract_job_requirements docstring) — this
# regex pass is a fast, dependency-free fallback that still demonstrates
# the "unstructured -> structured" transformation the spec asks for.
_SKILL_VOCAB = [
    "python", "sql", "spark", "airflow", "kafka", "dbt", "snowflake",
    "aws", "azure", "gcp", "docker", "kubernetes", "postgresql", "postgres",
    "etl", "elt", "machine learning", "pandas", "scala", "java", "terraform",
    "databricks", "bigquery", "redshift", "langchain", "langgraph", "nosql",
]


def _search_jobs(keyword: str = "", location: str = "", role: str = "") -> dict:
    with session_scope() as db:
        query = db.query(Job)
        filters = []
        if keyword:
            like = f"%{keyword}%"
            filters.append(or_(Job.title.ilike(like), Job.description.ilike(like)))
        if role:
            filters.append(Job.title.ilike(f"%{role}%"))
        if location:
            filters.append(Job.location.ilike(f"%{location}%"))
        if filters:
            for f in filters:
                query = query.filter(f)
        db_jobs = query.limit(20).all()

        if db_jobs:
            return {
                "source": "database",
                "count": len(db_jobs),
                "jobs": [
                    {
                        "id": str(j.id),
                        "title": j.title,
                        "company": j.company_name,
                        "location": j.location,
                        "required_skills": j.required_skills,
                    }
                    for j in db_jobs
                ],
            }

    # Nothing in Postgres yet -> fall back to the (mock or real) web provider.
    provider = get_web_search_provider()
    query_str = " ".join(filter(None, [role or keyword, location, "jobs"]))
    results = provider.search(query_str, max_results=5)
    return {
        "source": "web_search",
        "count": len(results),
        "jobs": results,
        "note": "No matching jobs in the database yet; showing web search results.",
    }


@tool
def search_jobs(keyword: str = "", location: str = "", role: str = "") -> dict:
    """
    Search for jobs by keyword, location, and/or role. Checks the local
    database first, then falls back to web search.

    Args:
        keyword: Free-text keyword, e.g. "data engineer".
        location: City/region/country filter, e.g. "India".
        role: A specific role/title filter, e.g. "Data Engineer".
    """
    return safe_tool_call(_search_jobs, keyword=keyword, location=location, role=role)


def _extract_job_requirements(job_description: str) -> dict:
    if not job_description or not job_description.strip():
        return {"error": "job_description is required"}

    text_lower = job_description.lower()
    found_skills = sorted({s for s in _SKILL_VOCAB if s in text_lower})

    years_match = re.search(r"(\d+)\+?\s*years?", text_lower)
    min_years = int(years_match.group(1)) if years_match else None

    return {
        "skills": found_skills,
        "min_years_experience": min_years,
        "note": (
            "Extracted via keyword matching against a known skill vocabulary. "
            "For production use, replace this with an LLM structured-output call "
            "for higher recall on skills outside the vocabulary."
        ),
    }


@tool
def extract_job_requirements(job_description: str) -> dict:
    """
    Convert a free-text job description into structured requirements
    (skills mentioned, minimum years of experience if stated).

    Args:
        job_description: The full text of a job posting.
    """
    return safe_tool_call(_extract_job_requirements, job_description=job_description)


def _rank_jobs(jobs_json: str, user_skills_json: str) -> dict:
    try:
        jobs = json.loads(jobs_json)
        user_skills = {s.lower() for s in json.loads(user_skills_json)}
    except (json.JSONDecodeError, TypeError) as exc:
        return {"error": f"jobs_json/user_skills_json must be valid JSON: {exc}"}

    if not isinstance(jobs, list):
        return {"error": "jobs_json must be a JSON list of job objects"}

    ranked = []
    for job in jobs:
        job_skills = {s.lower() for s in job.get("required_skills") or job.get("skills") or []}
        matched = sorted(job_skills & user_skills)
        missing = sorted(job_skills - user_skills)
        score = round(len(matched) / len(job_skills), 3) if job_skills else 0.0
        ranked.append(
            {
                "title": job.get("title"),
                "company": job.get("company") or job.get("company_name"),
                "score": score,
                "matched_skills": matched,
                "missing_skills": missing,
            }
        )
    ranked.sort(key=lambda r: r["score"], reverse=True)

    common_missing: dict[str, int] = {}
    for r in ranked:
        for skill in r["missing_skills"]:
            common_missing[skill] = common_missing.get(skill, 0) + 1

    return {
        "ranked_jobs": ranked,
        "common_missing_skills": sorted(common_missing, key=common_missing.get, reverse=True),
    }


@tool
def rank_jobs(jobs_json: str, user_skills_json: str) -> dict:
    """
    Compare several jobs against the user's skills and rank them by match
    score, also surfacing which missing skills are most common across jobs.

    Args:
        jobs_json: JSON list of job objects, each with a "required_skills" list.
        user_skills_json: JSON list of the user's skill strings.
    """
    return safe_tool_call(_rank_jobs, jobs_json=jobs_json, user_skills_json=user_skills_json)
