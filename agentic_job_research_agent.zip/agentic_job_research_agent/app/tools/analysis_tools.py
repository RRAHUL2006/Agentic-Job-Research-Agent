"""
app/tools/analysis_tools.py
-------------------------------
WHAT: `calculate_match_score` and `create_learning_plan`.
WHY:  Section 19 requires a *transparent* matching methodology (matched /
      missing / partial skills, no unfounded hiring-success claims).
      Section 9 requires turning missing skills into a structured learning
      plan.
"""
from __future__ import annotations

import json

from langchain_core.tools import tool

from app.tools.base import safe_tool_call

# Skills considered "close enough" to count as a partial match, e.g. knowing
# Postgres partially covers a "SQL" requirement. Deliberately small and
# explicit — this is the kind of business logic that should be visible and
# editable, not hidden behind a model call.
_RELATED_SKILLS = {
    "sql": {"postgresql", "postgres", "mysql", "bigquery", "redshift", "snowflake"},
    "python": {"pandas", "pyspark"},
    "spark": {"pyspark", "databricks"},
    "cloud": {"aws", "azure", "gcp"},
}


def _calculate_match_score(job_skills_json: str, user_skills_json: str) -> dict:
    try:
        job_skills = [s.lower().strip() for s in json.loads(job_skills_json)]
        user_skills = {s.lower().strip() for s in json.loads(user_skills_json)}
    except (json.JSONDecodeError, TypeError) as exc:
        return {"error": f"Both arguments must be valid JSON lists: {exc}"}

    if not job_skills:
        return {"error": "job_skills_json must contain at least one skill"}

    matched, partial, missing = [], [], []
    for skill in job_skills:
        if skill in user_skills:
            matched.append(skill)
            continue
        related = _RELATED_SKILLS.get(skill, set())
        if related & user_skills:
            partial.append({"required": skill, "user_has": sorted(related & user_skills)})
        else:
            missing.append(skill)

    total = len(job_skills)
    score = round((len(matched) + 0.5 * len(partial)) / total, 3) if total else 0.0

    return {
        "score": score,
        "matched_skills": matched,
        "partial_matches": partial,
        "missing_skills": missing,
        "methodology": (
            "score = (exact_matches + 0.5*partial_matches) / total_required_skills. "
            "This reflects skill overlap only — it is NOT a prediction of hiring "
            "outcome or interview performance."
        ),
    }


@tool
def calculate_match_score(job_skills_json: str, user_skills_json: str) -> dict:
    """
    Compute a transparent skill-overlap match score between a job's
    required skills and the user's skills. Returns matched, partially
    matched, and missing skills plus the exact methodology used. This
    score reflects skill overlap only, not predicted hiring success.

    Args:
        job_skills_json: JSON list of required skill strings.
        user_skills_json: JSON list of the user's skill strings.
    """
    return safe_tool_call(_calculate_match_score, job_skills_json=job_skills_json, user_skills_json=user_skills_json)


def _create_learning_plan(missing_skills_json: str) -> dict:
    try:
        missing_skills = json.loads(missing_skills_json)
    except (json.JSONDecodeError, TypeError) as exc:
        return {"error": f"missing_skills_json must be a valid JSON list: {exc}"}

    if not missing_skills:
        return {"plan": [], "note": "No missing skills provided — nothing to plan."}

    # Priority heuristic: skills that unlock other skills (foundational)
    # come first. Simple explicit ordering beats a black-box "AI decides".
    priority_order = ["python", "sql", "cloud", "aws", "azure", "gcp", "spark", "airflow", "kafka", "dbt"]

    def priority_key(skill: str) -> int:
        skill = skill.lower()
        return priority_order.index(skill) if skill in priority_order else len(priority_order)

    ordered = sorted(missing_skills, key=priority_key)

    plan = [
        {
            "skill": skill,
            "priority": i + 1,
            "suggested_action": f"Complete a focused project or course covering {skill}.",
            "status": "pending",
        }
        for i, skill in enumerate(ordered)
    ]
    return {"plan": plan}


@tool
def create_learning_plan(missing_skills_json: str) -> dict:
    """
    Turn a list of missing skills into a prioritized, structured learning
    plan.

    Args:
        missing_skills_json: JSON list of missing skill strings.
    """
    return safe_tool_call(_create_learning_plan, missing_skills_json=missing_skills_json)
