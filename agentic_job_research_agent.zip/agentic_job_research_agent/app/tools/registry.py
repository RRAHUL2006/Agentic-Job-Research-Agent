"""
app/tools/registry.py
------------------------
WHAT: The single list of LangChain tools the agent is allowed to call.
WHY:  Section 14: "Only registered LangChain tools can be called." The
      agent node (app/graph/nodes.py) imports ALL_TOOLS and
      TOOLS_BY_NAME from here — it never constructs or discovers tools
      any other way. This is the project's whitelist.
"""
from __future__ import annotations

from langchain_core.tools import BaseTool

from app.tools.analysis_tools import calculate_match_score, create_learning_plan
from app.tools.company_tools import get_company_info
from app.tools.job_tools import extract_job_requirements, rank_jobs, search_jobs
from app.tools.memory_tools import recall, remember
from app.tools.retrieval_tools import retrieve_documents_tool

ALL_TOOLS: list[BaseTool] = [
    search_jobs,
    get_company_info,
    calculate_match_score,
    remember,
    recall,
    retrieve_documents_tool,
    extract_job_requirements,
    rank_jobs,
    create_learning_plan,
]

TOOLS_BY_NAME: dict[str, BaseTool] = {t.name: t for t in ALL_TOOLS}
