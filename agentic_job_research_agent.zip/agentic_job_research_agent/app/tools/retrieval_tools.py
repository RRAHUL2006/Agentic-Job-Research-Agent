"""
app/tools/retrieval_tools.py
--------------------------------
WHAT: `retrieve_documents` — the RAG tool the agent calls to pull relevant
      context (resume chunks, company notes, job descriptions, interview
      prep material) out of pgvector.
WHY:  Thin adapter over app/retrieval/retriever.py so it can be exposed to
      the LLM as a callable tool with a plain-JSON-friendly signature.
"""
from __future__ import annotations

from langchain_core.tools import tool

from app.db.session import session_scope
from app.retrieval.retriever import RetrievalError, retrieve_documents
from app.tools.base import safe_tool_call


def _retrieve_documents(query: str, top_k: int = 5, doc_type: str = "") -> dict:
    if not query or not query.strip():
        return {"error": "query is required"}
    with session_scope() as db:
        try:
            chunks = retrieve_documents(db, query, top_k=top_k, doc_type=doc_type or None)
        except RetrievalError as exc:
            return {"error": str(exc)}

    if not chunks:
        return {"results": [], "note": "No matching documents found. Have any been ingested yet?"}

    return {
        "results": [
            {
                "source": c.source,
                "document_id": c.document_id,
                "chunk_id": c.chunk_id,
                "content": c.content,
                "similarity_score": c.similarity_score,
                "metadata": c.metadata,
            }
            for c in chunks
        ]
    }


@tool
def retrieve_documents_tool(query: str, top_k: int = 5, doc_type: str = "") -> dict:
    """
    Retrieve the most relevant document chunks (resume, company profiles,
    job descriptions, interview notes, learning resources) for a query
    using pgvector cosine similarity search.

    Args:
        query: What to search for.
        top_k: Number of chunks to return.
        doc_type: Optional filter, e.g. "resume", "company_profile", "job_description".
    """
    return safe_tool_call(_retrieve_documents, query=query, top_k=top_k, doc_type=doc_type)
