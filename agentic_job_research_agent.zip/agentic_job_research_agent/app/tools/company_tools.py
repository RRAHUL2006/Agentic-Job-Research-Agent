"""
app/tools/company_tools.py
-----------------------------
WHAT: `get_company_info` — looks a company up in Postgres first (fast,
      previously-researched data); if it's not there, uses the web search
      provider to build a fresh (clearly-labeled) summary and caches it.
WHY:  This demonstrates the "check memory/DB before going to the network"
      pattern that real agents use to stay fast and cheap.
"""
from __future__ import annotations

from langchain_core.tools import tool

from app.db.models import Company
from app.db.session import session_scope
from app.tools.base import safe_tool_call
from app.tools.web_tools import get_web_search_provider


def _get_company_info(company: str) -> dict:
    if not company or not company.strip():
        return {"error": "company name is required"}
    company = company.strip()

    with session_scope() as db:
        existing = db.query(Company).filter(Company.name.ilike(company)).first()
        if existing:
            return {
                "company": existing.name,
                "industry": existing.industry,
                "summary": existing.summary,
                "source": "database_cache",
            }

        provider = get_web_search_provider()
        results = provider.search(f"{company} company overview engineering data AI", max_results=3)
        if not results:
            return {"company": company, "summary": None, "source": "web_search", "note": "No results found."}

        summary = " ".join(r["snippet"] for r in results if "snippet" in r)
        is_mock = any(r.get("mock") for r in results)

        record = Company(name=company, summary=summary, company_metadata={"mock_data": is_mock})
        db.add(record)

        return {
            "company": company,
            "summary": summary,
            "source": "web_search",
            "mock_data": is_mock,
            "note": "Synthetic/mock data — replace WEB_SEARCH_PROVIDER for real research." if is_mock else None,
        }


@tool
def get_company_info(company: str) -> dict:
    """
    Look up information about a company (industry, summary) to support
    company research and interview preparation.

    Args:
        company: The company name, e.g. "BP".
    """
    return safe_tool_call(_get_company_info, company=company)
