"""
app/tools/web_tools.py
-------------------------
WHAT: A WebSearchProvider interface (search / fetch / extract) plus a
      MockWebSearchProvider that returns realistic-shaped, clearly-labeled
      synthetic data so the whole project runs with zero API keys.
WHY:  Section 17: "Do not tightly couple the application to a single
      provider" and "Never fabricate web evidence." The mock provider
      makes it obvious it's mock data (mock=True on every result, and a
      note field) — an LLM reading this context cannot mistake it for a
      real citation, and a student can swap in Tavily/Serper/Bing by
      implementing the same three methods.
IN:   query string (search), url string (fetch/extract).
OUT:  Structured dicts. Handles timeouts, retries, invalid URLs, duplicate
      results, empty results, and oversized responses.
"""
from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from urllib.parse import urlparse

import httpx
from tenacity import retry, stop_after_attempt, wait_fixed

from app.config import settings

logger = logging.getLogger(__name__)

MAX_RESPONSE_CHARS = 20_000  # guard against "large responses" (spec section 17)


class WebSearchProvider(ABC):
    @abstractmethod
    def search(self, query: str, max_results: int = 5) -> list[dict]:
        ...

    @abstractmethod
    def fetch(self, url: str) -> dict:
        ...

    @abstractmethod
    def extract(self, content: str) -> str:
        ...


class MockWebSearchProvider(WebSearchProvider):
    """
    Deterministic, offline-friendly provider. Lets the whole agent graph,
    including the "research a company" workflow, run without any external
    API key. Every result is clearly flagged as mock data so it is never
    confused with real evidence in the final answer.
    """

    def search(self, query: str, max_results: int = 5) -> list[dict]:
        if not query or not query.strip():
            return []
        base = query.strip()
        results = [
            {
                "title": f"[MOCK] Overview related to '{base}'",
                "url": f"https://example.com/mock-search?q={base.replace(' ', '+')}",
                "snippet": (
                    f"This is synthetic placeholder content standing in for a real web "
                    f"result about '{base}'. Configure WEB_SEARCH_PROVIDER=real and a "
                    f"real provider in app/tools/web_tools.py to replace this."
                ),
                "mock": True,
            }
        ]
        # Deduplicate by URL (spec: handle duplicate results) — trivial here but
        # the same logic applies once a real provider can return dupes.
        seen_urls = set()
        deduped = []
        for r in results[:max_results]:
            if r["url"] in seen_urls:
                continue
            seen_urls.add(r["url"])
            deduped.append(r)
        return deduped

    def fetch(self, url: str) -> dict:
        parsed = urlparse(url)
        if not parsed.scheme or not parsed.netloc:
            return {"error": f"Invalid URL: {url!r}", "mock": True}
        return {
            "url": url,
            "content": f"[MOCK] Synthetic page content for {url}.",
            "mock": True,
        }

    def extract(self, content: str) -> str:
        return content[:MAX_RESPONSE_CHARS]


class HttpWebSearchProvider(WebSearchProvider):
    """
    Skeleton for a REAL provider. Not wired to any specific vendor on
    purpose (the spec explicitly says "add an optional real provider
    later"). To activate: implement `search()` against your chosen API
    (Tavily, Serper, Bing, etc.), set WEB_SEARCH_PROVIDER=real and
    WEB_SEARCH_API_KEY in .env.
    """

    def __init__(self, api_key: str | None):
        if not api_key:
            raise ValueError("HttpWebSearchProvider requires WEB_SEARCH_API_KEY to be set")
        self.api_key = api_key

    def search(self, query: str, max_results: int = 5) -> list[dict]:
        raise NotImplementedError(
            "Wire this method up to a real search API (Tavily/Serper/Bing/etc.)."
        )

    @retry(reraise=True, stop=stop_after_attempt(2), wait=wait_fixed(1))
    def fetch(self, url: str) -> dict:
        parsed = urlparse(url)
        if not parsed.scheme or not parsed.netloc:
            return {"error": f"Invalid URL: {url!r}"}
        try:
            with httpx.Client(timeout=10.0) as client:
                resp = client.get(url)
                resp.raise_for_status()
                text = resp.text[:MAX_RESPONSE_CHARS]
                return {"url": url, "content": text, "mock": False}
        except httpx.TimeoutException as exc:
            return {"error": f"Timed out fetching {url}: {exc}"}
        except httpx.HTTPError as exc:
            return {"error": f"HTTP error fetching {url}: {exc}"}

    def extract(self, content: str) -> str:
        return content[:MAX_RESPONSE_CHARS]


def get_web_search_provider() -> WebSearchProvider:
    if settings.web_search_provider == "real":
        return HttpWebSearchProvider(settings.web_search_api_key)
    return MockWebSearchProvider()
