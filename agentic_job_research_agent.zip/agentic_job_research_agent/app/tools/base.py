"""
app/tools/base.py
------------------
WHAT: A `safe_tool_call` wrapper every tool's underlying function can be
      run through, so tool failures become structured error dicts instead
      of raw exceptions bubbling into the graph.
WHY:  Section 14 of the spec: "Tools must execute safely... never allow
      arbitrary shell commands... validate tool arguments." Tools here
      are plain Python functions wrapped with @tool from LangChain — there
      is no eval(), no subprocess, no dynamic code execution anywhere in
      this codebase. This wrapper adds the other half: predictable error
      shapes so the agent node can reason about failures instead of
      crashing.
"""
from __future__ import annotations

import logging
import time
from typing import Any, Callable

logger = logging.getLogger(__name__)


def safe_tool_call(fn: Callable[..., dict], **kwargs: Any) -> dict:
    """
    Runs `fn(**kwargs)`, timing it and catching any exception into a
    structured `{"error": ...}` result rather than letting it propagate.
    Every LangChain @tool function in this package should be a thin
    wrapper that calls a plain function through this.
    """
    start = time.perf_counter()
    try:
        result = fn(**kwargs)
        duration_ms = int((time.perf_counter() - start) * 1000)
        if isinstance(result, dict):
            result.setdefault("_duration_ms", duration_ms)
        return result
    except Exception as exc:  # noqa: BLE001 - tool boundary, must not crash the graph
        duration_ms = int((time.perf_counter() - start) * 1000)
        logger.warning("Tool %s failed after %dms: %s", fn.__name__, duration_ms, exc)
        return {"error": str(exc), "_duration_ms": duration_ms}
