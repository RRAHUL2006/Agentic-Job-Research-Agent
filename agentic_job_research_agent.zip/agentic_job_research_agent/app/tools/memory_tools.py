"""
app/tools/memory_tools.py
-----------------------------
WHAT: `remember` and `recall` — the agent's long-term memory tools.
WHY:  Section 9/15/16 of the spec. `remember` upserts a key/value pair AND
      writes a semantic-memory embedding (so both exact-key lookups and
      "what did they say about X" fuzzy lookups work). `recall` checks
      key/value memory first (cheap, exact) then falls back to semantic
      similarity search.
IN:   user_id (string UUID), a key/value pair (remember) or a query
      (recall).
OUT:  Structured confirmation / retrieved memories.
"""
from __future__ import annotations

import uuid

from langchain_core.tools import tool

from app.db.models import Memory, SemanticMemory
from app.db.session import session_scope
from app.retrieval.embeddings import EmbeddingUnavailableError, embed_text
from app.retrieval.retriever import RetrievalError, retrieve_semantic_memories
from app.tools.base import safe_tool_call


def _remember(user_id: str, memory_key: str, memory_value: str) -> dict:
    try:
        uid = uuid.UUID(user_id)
    except ValueError:
        return {"error": f"user_id must be a valid UUID, got {user_id!r}"}
    if not memory_key or not memory_value:
        return {"error": "memory_key and memory_value are both required"}

    with session_scope() as db:
        existing = db.query(Memory).filter_by(user_id=uid, memory_key=memory_key).first()
        if existing:
            existing.memory_value = memory_value
        else:
            db.add(Memory(user_id=uid, memory_key=memory_key, memory_value=memory_value))

        # Also index it semantically so future fuzzy queries ("what does the
        # user prefer for location?") can surface it even without the exact key.
        try:
            embedding = embed_text(f"{memory_key}: {memory_value}")
            db.add(SemanticMemory(user_id=uid, text=f"{memory_key}: {memory_value}", embedding=embedding))
            semantic_indexed = True
        except EmbeddingUnavailableError:
            # Key/value memory still succeeds even if embeddings are down —
            # this is the graceful-degradation path from section 22.
            semantic_indexed = False

    return {"stored": True, "memory_key": memory_key, "semantic_indexed": semantic_indexed}


@tool
def remember(user_id: str, memory_key: str, memory_value: str) -> dict:
    """
    Store a user preference or fact in long-term memory, e.g.
    memory_key="target_role", memory_value="Data Engineering".

    Args:
        user_id: The user's UUID as a string.
        memory_key: Short identifier for what's being remembered.
        memory_value: The value to remember.
    """
    return safe_tool_call(_remember, user_id=user_id, memory_key=memory_key, memory_value=memory_value)


def _recall(user_id: str, query: str, top_k: int = 5) -> dict:
    try:
        uid = uuid.UUID(user_id)
    except ValueError:
        return {"error": f"user_id must be a valid UUID, got {user_id!r}"}

    with session_scope() as db:
        # Exact key/value matches first (cheap, precise).
        exact = db.query(Memory).filter(Memory.user_id == uid, Memory.memory_key.ilike(f"%{query}%")).all()
        exact_results = [{"key": m.memory_key, "value": m.memory_value, "match_type": "exact_key"} for m in exact]

        # Then semantic similarity for anything the exact match missed.
        try:
            semantic = retrieve_semantic_memories(db, uid, query, top_k=top_k)
            semantic_results = [
                {"value": r.content, "similarity_score": r.similarity_score, "match_type": "semantic"}
                for r in semantic
            ]
        except RetrievalError as exc:
            semantic_results = []
            return {
                "exact_matches": exact_results,
                "semantic_matches": semantic_results,
                "warning": f"Semantic recall unavailable: {exc}",
            }

    return {"exact_matches": exact_results, "semantic_matches": semantic_results}


@tool
def recall(user_id: str, query: str, top_k: int = 5) -> dict:
    """
    Retrieve relevant long-term memories for a user, combining exact
    key/value lookups with semantic similarity search.

    Args:
        user_id: The user's UUID as a string.
        query: What to recall, e.g. "preferred role" or "location preference".
        top_k: Max semantic matches to return.
    """
    return safe_tool_call(_recall, user_id=user_id, query=query, top_k=top_k)
