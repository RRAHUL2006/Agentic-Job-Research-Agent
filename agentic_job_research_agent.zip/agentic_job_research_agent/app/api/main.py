"""
app/api/main.py
------------------
WHAT: The FastAPI application exposing the agent over HTTP.
WHY:  Section 25 of the spec, verbatim endpoint list. This is a thin
      layer: every handler delegates to app/agent/runtime.py,
      app/retrieval/*, or direct (simple) queries — no business logic
      lives here.

Run with:  uvicorn app.api.main:app --reload
"""
from __future__ import annotations

import uuid

from fastapi import Depends, FastAPI, HTTPException
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.agent.llm import LLMUnavailableError, get_llm, invoke_with_recovery
from app.agent.runtime import run_agent
from app.config import settings
from app.db.models import AgentTrace, Company, Job, Memory
from app.db.session import get_db
from app.evaluation.evaluator import run_evaluation_suite
from app.models.schemas import (
    AgentRequest,
    AgentResponse,
    EvaluateRequest,
    HealthResponse,
    MemoryReadResponse,
    MemoryWriteRequest,
    RetrieveRequest,
    RetrieveResponse,
)
from app.retrieval.embeddings import EmbeddingUnavailableError, embed_text
from app.retrieval.retriever import RetrievalError, retrieve_documents
from app.tools.memory_tools import remember as remember_tool

app = FastAPI(
    title="Agentic Job Research Agent API",
    description="Educational agentic AI system: LangGraph + Ollama + Postgres/pgvector.",
    version="1.0.0",
)


@app.get("/health", response_model=HealthResponse)
def health(db: Session = Depends(get_db)) -> HealthResponse:
    ollama_status = "ok"
    try:
        invoke_with_recovery(get_llm(), [])
    except LLMUnavailableError:
        ollama_status = "unavailable"
    except Exception:  # noqa: BLE001 - empty message list may raise a different error; treat as reachable-but-unclear
        ollama_status = "unknown"

    postgres_status = "ok"
    pgvector_status = "unknown"
    try:
        db.execute(text("SELECT 1"))
        try:
            db.execute(text("SELECT '[1,2,3]'::vector"))
            pgvector_status = "ok"
        except Exception:  # noqa: BLE001
            pgvector_status = "extension_missing"
    except Exception:  # noqa: BLE001
        postgres_status = "unavailable"

    overall = "ok" if postgres_status == "ok" else "degraded"
    return HealthResponse(status=overall, ollama=ollama_status, postgres=postgres_status, pgvector=pgvector_status)


@app.post("/agent", response_model=AgentResponse)
def agent_endpoint(payload: AgentRequest) -> AgentResponse:
    result = run_agent(payload.user_request, user_id=payload.user_id, session_id=payload.session_id)
    return AgentResponse(**result)


@app.post("/memory")
def write_memory(payload: MemoryWriteRequest) -> dict:
    result = remember_tool.invoke(
        {"user_id": payload.user_id, "memory_key": payload.memory_key, "memory_value": payload.memory_value}
    )
    if result.get("error"):
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@app.get("/memory", response_model=MemoryReadResponse)
def read_memory(user_id: str, db: Session = Depends(get_db)) -> MemoryReadResponse:
    try:
        uid = uuid.UUID(user_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="user_id must be a valid UUID")
    rows = db.query(Memory).filter_by(user_id=uid).order_by(Memory.updated_at.desc()).all()
    return MemoryReadResponse(
        memories=[{"key": m.memory_key, "value": m.memory_value, "updated_at": m.updated_at.isoformat()} for m in rows]
    )


@app.post("/retrieve", response_model=RetrieveResponse)
def retrieve(payload: RetrieveRequest, db: Session = Depends(get_db)) -> RetrieveResponse:
    try:
        chunks = retrieve_documents(db, payload.query, top_k=payload.top_k, doc_type=payload.doc_type)
    except (RetrievalError, EmbeddingUnavailableError) as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    return RetrieveResponse(
        results=[
            {
                "source": c.source,
                "document_id": c.document_id,
                "chunk_id": c.chunk_id,
                "content": c.content,
                "similarity_score": c.similarity_score,
                "metadata": c.metadata,
            }
            for c in chunks
        ]
    )


@app.get("/traces/{session_id}")
def get_traces(session_id: str, db: Session = Depends(get_db)) -> dict:
    try:
        sid = uuid.UUID(session_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="session_id must be a valid UUID")
    rows = db.query(AgentTrace).filter_by(session_id=sid).order_by(AgentTrace.created_at.asc()).all()
    return {
        "session_id": session_id,
        "traces": [
            {
                "node": t.node,
                "event_type": t.event_type,
                "tool_name": t.tool_name,
                "status": t.status,
                "duration_ms": t.duration_ms,
                "created_at": t.created_at.isoformat(),
            }
            for t in rows
        ],
    }


@app.post("/evaluate")
def evaluate(payload: EvaluateRequest) -> dict:
    return run_evaluation_suite(task_name=payload.task_name)


@app.get("/jobs")
def list_jobs(db: Session = Depends(get_db), limit: int = 50) -> dict:
    rows = db.query(Job).order_by(Job.created_at.desc()).limit(limit).all()
    return {
        "jobs": [
            {
                "id": str(j.id),
                "title": j.title,
                "company": j.company_name,
                "location": j.location,
                "required_skills": j.required_skills,
            }
            for j in rows
        ]
    }


@app.get("/companies/{company}")
def get_company(company: str, db: Session = Depends(get_db)) -> dict:
    row = db.query(Company).filter(Company.name.ilike(company)).first()
    if not row:
        raise HTTPException(status_code=404, detail=f"No stored research for company: {company}")
    return {"company": row.name, "industry": row.industry, "summary": row.summary}
